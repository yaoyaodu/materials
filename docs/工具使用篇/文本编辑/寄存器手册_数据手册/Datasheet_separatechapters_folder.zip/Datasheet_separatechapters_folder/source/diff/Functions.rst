Functions6011
===============

Core
----

-  The ARM STAR and HiFi4 dual-core operates up to 300 MHz.

-  Independent NPU.

-  Hardware multiplier and hardware divider.

-  The embedded debug module supports the serial debug port (2-wire) and the JTAG debug port (4-wire).

Memory
------

-  External flash through the QSPI interface.

-  Totally 1088-KB SRAM shared by ARM and HiFi4 cores.

-  Dedicated 96-KB SRAM for the NPU block.

Clock Control
-------------

-  Programmable system clock source.

-  External 24-MHz high-speed crystal input to provide reference clock for the system.

-  Internal 32-KHz low-speed oscillator with calibration.

-  The PLL allows CPU operation up to 300 MHz with the system oscillator.

IO Port
-------

-  Up to 32 GPIO pins.

-  GPIO configuration.

-  Quasi-bidirectional (pull-up enabled).

-  Pull-down.

-  Push-pull (output).

-  Input only (high-impedance).

-  An I/O pin can be configured as an interrupt source through edge/level configuration.

-  Flexible IO function selection.

-  5-V tolerance IO for GPIOA.

GPT
---

The multi-function timer provides the following 4 usage scenarios
depending on the configuration of the channel mode register bit. The maximum
output frequency of the PWM is 50 MHz.

-  | Timer mode
   | Support 8/16/32-bit timers.

-  | Input capture mode
   | The capture count mode is used to capture the number of input pulses and the capture time mode 
     is used to capture pulse width.

-  LEDC output mode

-  | PWM mode
   | PWM can be configured as central-aligned mode (see :ref:`Fig. 4.1 <4-1>`) and
     edge-aligned mode (see :ref:`Fig. 4.2 <4-2>`).

   .. _4-1:

   .. figure:: ../datasheet_figure/4-1_Center-Aligned_Mode.png
      :scale: 30%
      :align: center

      Center-Aligned Mode

   .. _4-2:

   .. figure:: ../datasheet_figure/4-2_Edge-Aligned_Mode.png
      :scale: 30%

      Edge-Aligned Mode

   - PWM output duty cycle 0% and 100%  

     If the duty cycle is set to 0% or 100%, the shadow register of the GPT module will not work.  
     This will lead to pulse generation when the duty cycle is changed dynamically from zero 
     to none-zero or from 100 to any other value.

   .. figure:: ../datasheet_figure/4-3.png
      :scale: 60%
      :align: center

      Duty Change from 50% to 0

   - PWM output duty cycle error

     The PWM output duty cycle error depends on the frequency out and clock select values.
   
     Take the PWM edge-aligned mode for example:

     The actual high and low periods of PWM are \*1 + high period\* and \*1 + low period\* 
     respectively.

     :ref:`Table 4.1 <newtable>` shows that different dividers will lead to different duty errors.

     If the divider is set to 32, the real PWM clock is 100\*10^6/32 and the total period PWM 
     counter value is small (32).

     If the divider is set to 8, the real PWM clock is 100\*10^6/8 and the total period PWM counter value is big (125). 
     this will greatly reduce duty errors.

     If the target PWM frequency is 10 MHz and the divider is set to 1, the real PWM clock is 100\*10^6/1, the total period 
     PWM counter value is very small (10). This will greatly increase duty errors.


.. _newtable:

.. table:: High Duty Counter Value VS Duty
    :widths: 38 10 10 10

    +-----------------------------+-------------------+-------------------+-------------------+-------------------+
    | **Clock Frequency           | 100000000         | 100000000         | 100000000         | 100000000         |
    | Select (Hz)**               |                   |                   |                   |                   |
    +-----------------------------+-------------------+-------------------+-------------------+-------------------+
    | **Divider**                 | 128               | 32                | 8                 | 1                 |
    +-----------------------------+-------------------+-------------------+-------------------+-------------------+
    | **Target                    | 100000            | 100000            | 100000            | 10000000          |
    | PWM                         |                   |                   |                   |                   |
    | Frequency                   |                   |                   |                   |                   |
    | (Hz)**                      |                   |                   |                   |                   |
    +-----------------------------+-------------------+-------------------+-------------------+-------------------+
    | **Total                     | 5                 | 29                | 123               | 8                 |
    | PWM                         |                   |                   |                   |                   |
    | Counter                     |                   |                   |                   |                   |
    | Value**                     |                   |                   |                   |                   |
    +-----------------------------+---------+---------+---------+---------+---------+---------+---------+---------+
    | **High                      | Count   | Duty    | Count   | Duty    | Count   | Duty    | Count   | Duty    |
    | Duty                        | Value   | (%)     | Value   | (%)     | Value   | (%)     | Value   | (%)     |
    | Counter                     |         |         |         |         |         |         |         |         |
    | Value                       |         |         |         |         |         |         |         |         |
    | VS                          |         |         |         |         |         |         |         |         |
    | Duty**                      |         |         |         |         |         |         |         |         |
    |                             +---------+---------+---------+---------+---------+---------+---------+---------+
    |                             | 1       | 28      | 1       | 6       | 1       | 1       | 1       | 20      |
    |                             +---------+---------+---------+---------+---------+---------+---------+---------+
    |                             | 2       | 42      | 2       | 9       | 2       | 2       | 2       | 30      |
    |                             +---------+---------+---------+---------+---------+---------+---------+---------+
    |                             | 3       | 57      | 3       | 12      | 3       | 3       | 3       | 40      |
    |                             +---------+---------+---------+---------+---------+---------+---------+---------+
    |                             | 4       | 71      | 4       | 16      | 4       | 4       | 4       | 50      |
    |                             +---------+---------+---------+---------+---------+---------+---------+---------+
    |                             | \-      | \-      | 5       | 19      | 5       | 4       | 5       | 60      |
    |                             +---------+---------+---------+---------+---------+---------+---------+---------+
    |                             | \-      | \-      | 6       | 22      | 6       | 5       | 6       | 70      |
    |                             +---------+---------+---------+---------+---------+---------+---------+---------+
    |                             | \-      | \-      | 7       | 25      | 7       | 6       | 7       | 80      |
    |                             +---------+---------+---------+---------+---------+---------+---------+---------+
    |                             | \-      | \-      | 8       | 29      | 8       | 7       | 8       | 90      |
    |                             +---------+---------+---------+---------+---------+---------+---------+---------+
    |                             | \-      | \-      | 9       | 32      | 9       | 8       | \-      | \-      |
    |                             +---------+---------+---------+---------+---------+---------+---------+---------+
    |                             | \-      | \-      | 10      | 35      | 10      | 8       | \-      | \-      |
    |                             +---------+---------+---------+---------+---------+---------+---------+---------+
    |                             | \-      | \-      | 11      | 38      | 11      | 9       | \-      | \-      |
    |                             +---------+---------+---------+---------+---------+---------+---------+---------+
    |                             | \-      | \-      | 12      | 41      | 12      | 10      | \-      | \-      |
    |                             +---------+---------+---------+---------+---------+---------+---------+---------+
    |                             | \-      | \-      | 13      | 45      | 13      | 11      | \-      | \-      |
    |                             +---------+---------+---------+---------+---------+---------+---------+---------+
    |                             | \-      | \-      | 14      | 48      | 14      | 12      | \-      | \-      |
    |                             +---------+---------+---------+---------+---------+---------+---------+---------+
    |                             | \-      | \-      | 15      | 51      | 15      | 12      | \-      | \-      |
    |                             +---------+---------+---------+---------+---------+---------+---------+---------+
    |                             | \-      | \-      | 16      | 54      | 16      | 13      | \-      | \-      |
    |                             +---------+---------+---------+---------+---------+---------+---------+---------+
    |                             | \-      | \-      | 17      | 58      | 17      | 14      | \-      | \-      |
    |                             +---------+---------+---------+---------+---------+---------+---------+---------+
    |                             | \-      | \-      | 18      | 61      | 18      | 15      | \-      | \-      |
    |                             +---------+---------+---------+---------+---------+---------+---------+---------+
    |                             | \-      | \-      | 19      | 64      | 19      | 16      | \-      | \-      |
    |                             +---------+---------+---------+---------+---------+---------+---------+---------+
    |                             | \-      | \-      | 20      | 67      | 20      | 16      | \-      | \-      |
    |                             +---------+---------+---------+---------+---------+---------+---------+---------+
    |                             | \-      | \-      | 21      | 70      | 21      | 17      | \-      | \-      |
    |                             +---------+---------+---------+---------+---------+---------+---------+---------+
    |                             | \-      | \-      | 22      | 74      | 22      | 18      | \-      | \-      |
    |                             +---------+---------+---------+---------+---------+---------+---------+---------+
    |                             | \-      | \-      | 23      | 77      | 23      | 19      | \-      | \-      |
    |                             +---------+---------+---------+---------+---------+---------+---------+---------+
    |                             | \-      | \-      | 24      | 80      | 24      | 20      | \-      | \-      |
    |                             +---------+---------+---------+---------+---------+---------+---------+---------+
    |                             | \-      | \-      | 25      | 83      | 25      | 20      | \-      | \-      |
    |                             +---------+---------+---------+---------+---------+---------+---------+---------+
    |                             | \-      | \-      | 26      | 87      | 26      | 21      | \-      | \-      |
    |                             +---------+---------+---------+---------+---------+---------+---------+---------+
    |                             | \-      | \-      | 27      | 90      | 27      | 22      | \-      | \-      |
    |                             +---------+---------+---------+---------+---------+---------+---------+---------+
    |                             | \-      | \-      | 28      | 93      | 28      | 23      | \-      | \-      |
    +-----------------------------+---------+---------+---------+---------+---------+---------+---------+---------+
    | Note:                                                                                                       |
    |                                                                                                             |
    | - Total PWM counter value = (Clock Frequency Select)/Divider/(Targt PWM Frequency) - 2                      |
    |                                                                                                             |
    | - Duty (%) = (1 + count value)/(2 + Total PWM counter value)*100%                                           |
    +-------------------------------------------------------------------------------------------------------------+

SAR ADC
-------

-  12-bit resolution, up to 3 channels, up to 1 Msps, 24-MHz ADC clock.

-  Configurable hardware ADC trigger sources.

-  Configurable n-times ADC sampling.

-  Dedicated ADC data FIFO for each ADC channel.

-  Configurable ADC sampling duration.

-  Configurable waiting time for the next round of A/D conversion.

-  Switch on/off control.

-  ADC trimming.

-  ADC channel selection.

-  External/internal VREF selection.

-  | Real voltage calculation:
   | Reg\ :sub:`adc_value` = ADC register value
   | Voltage = (Reg\ :sub:`adc_value` - 2048)/2048*3.3

Audio Codec
-----------

-  Audio sample rates support 8 KHz to 96 KHz in the playback (DAC) path.

-  Audio sample rates support 8 KHz, 16 KHz, 44.1 KHz, or 48 KHz in the record (ADC) path.

-  | DAC SNR about 95 dB, THD -85 dB ('A'-weighted @ 8-48 KS/s).
   | ADC SNR about 95 dB, THD -85 dB ('A'-weighted @ 8-48 KS/s).

-  32-bit APB control interface to ADC01 separately.

-  32-bit APB control interface to ADC23 and DAC01 separately.

-  Programmable gain setting and soft mute control in the digital part.

-  | Programmable ALC loop/noise gate configuration in the ADC path.
   | Programmable ADC high-pass filter (wind noise reduction included).
   | The programmable ADC notch filter is selectable.

-  ADC01 and ADC23 support two stereo digital microphones.

-  Output gain/volume and mute control.

DVP
---

-  Designed as an AHB master component that can access the memory without any DMAC service.

-  Image frame completion notice and buffer switching.

-  Support 4:2:2 output format in the line buffer for JPEG encoding.

IWDG
----

-  Clocked from an internal 32-KHz low-speed oscillator or from a 32768-Hz crystal if available.

-  32-bit free-running counter.

-  Selectable timer-out interval.

UART
----

-  Four UART interfaces (1 for debug).

-  Three UARTs support hardware flow control (CTS/RTS) so that WiFi can be supported through UART interfaces.

-  UART0 to UART2 support hardware handshake for DMA.

-  Up to 3-Mb/s baudrate.

SPI
---

-  Three SPI interfaces.

-  Maximumly 50 Mb/s for the master mode.

-  Maximumly 25 Mb/s for the slave mode.

-  An SPI with the QSPI function must be used for the embedded NOR flash or the external flash.

-  Supports the master mode and the slave mode.

-  Supports memory mapped access (read-only) through the AHB bus.

-  Supports hardware handshake for DMA.

-  Supports the dual I/O mode and the quad I/O mode (QSPI).

I2C
---

-  Two I2C interfaces are available.

-  Programmable to be a master or a slave device.

-  Programmable clock/data timing.

-  Supports the I2C-bus standard-mode (100 kb/s), fast-mode (400 kb/s), and fast-mode plus (1 Mb/s).

-  Supports the hardware handshake for DMA.

-  Supports the master-transmit, master-receive, slave-transmit, and slave-receive modes.

-  Supports the multi-master mode.

-  Supports 7-bit and 10-bit addressing.

-  Supports general call addressing.

-  Supports automatic clock stretch.

RTC
---

-  Supports software compensation by setting the frequency compensation register.

-  The frequency of the clock source (before the clock divider) for the counter is 32.768 KHz.

-  Separate second, minute, hour, and day counters.

-  Periodic interrupts: half-second, second, minute, hour, and day interrupts.

-  Programmable alarm interrupt with specified second, minute, and hour numbers.

NPU
---

-  Matrix and vector operation accelerator.

-  AHB master interface for data read and write.

-  APB interface for register configuration.

-  Has interrupt signals.

-  Support reverse order storage, overflow detection, and location shift.

FCC RAM Controller
------------------

-  200 MHz maximumly. 

-  Arbitrate the data access request from the CPU, HiFi4, NPU, and DMAC.

-  Partition the NPU memory into several spaces.

-  If the accesses from different agents are in different spaces, all of them can be done immediately.

-  Flexible priority configuration: If the accesses from different agents are in the same space, the priority can be configured by users through the register.

PDM2PCM
-------

-  Support data conversion of PDM data from digital microphone to standard PCM data.

-  CIC filter in the always-on domain and half-band filter and memory in the main power domain.

CRYPTO
------

-  Support AES128 and SHA256 for secure communication.

-  AHB master interface for data read and write.

-  APB interface for register configuration.

eFuse Controller
----------------

-  Read eFuse content after receiving reset release signal from the reset sequence control.

-  Provide data to the crypto engine for encryption/decryption.

-  Provide data to the QSPI encryption wrapper to protect the content of the NOR flash.

True Random Number Generator
----------------------------

-  True random generator with mixed analog digital implementation to provide true random numbers.

-  Register configuration and generated random numbers can be accessed through the APB bus.

I2S Interface
-------------

-  Support extended microphone inputs.

-  Support I2S audio inputs and outputs.

-  3 independent I2S modules.

-  An input or output signal can be TDM-extended.

-  Register configuration and data operation through the APB bus.

USB1.1 Full Speed Device
------------------------

-  One set of 12-Mbps USB 1.1 FS device.

-  On-chip USB Transceiver.

-  Supports control, ISO in/out, bulk in/out, interrupt in/out transfers.

-  Provides 8 programmable endpoints.

-  Supports maximumly 1 KB for isochronous transfer and maximumly 64 bytes for bulk and interrupt transfer.

-  Each endpoint is configurable.

SDIO
----

-  Maximumly 25-MHz output clock

-  Compliant with the SD host controller standard specification, version 3.0.

-  Supports both DMA and non-DMA data transfer.

-  Compliant with the SD physical layer specification, version 3.0.

-  Supports UHS50/UHS104 SD cards.

-  Supports configurable SD bus modes: 4-bit mode and 8-bit mode.

-  Compliant with the SDIO card specification, version 3.0.

-  Compliant with the mandatory part in the eMMC card specification, version 5.1.

-  Supports configurable 1-bit/4-bit SD card bus and 1-bit/4-bit/8-bit EMMC card bus.

-  Configurable CPRM function for security.

-  Built-in generation and check for 7-bit and 16-bit CRC data.

-  Card detection (insertion/removal).

Power Management Unit
---------------------

-  Supports the sleep mode to reduce power consumption.

-  Supports wake-up through a RTC, timer, and key from IO.

-  Supports wake-up through VAD.

-  Supports system wakeup through touch.

Touch
-----

-  Supports touch point detection.

SRAM
-----

-  Bandwidth 600MHz.

PSRAM
-----

-  Bandwidth 400MHz(Max).

QSPI
-----

-  Supported 133MHz(Max).

Audio ADC/DMIC/I2S
------------------

-  The audio ADC shares the internal memory with the DMIC and the I2S. For the restrictions on combination use, refer to :ref:`Table 4.2 <Table4-1>`.

.. _Table4-1:

.. table:: Restrictions on Combination Use

   +----------------------+-------------------+--------------------+-----------------+
   | **Occupied ADC/DAC** | **Available I2S** | **Available DMIC** | **Description** |
   +======================+===================+====================+=================+
   | ADC01 only, no       | I2S1, I2S2        | DMIC2, DMIC3       |                 |
   | DAC                  |                   |                    |                 |
   +----------------------+-------------------+--------------------+-----------------+
   | ADC23 only, no       | I2S0, I2S1 or     | DMIC0, DMIC1       | I2S1 or I2S2    |
   | DAC                  | I2S2              |                    | (either-or)     |
   +----------------------+-------------------+--------------------+-----------------+
   | ADC01+ADC23,         | I2S1 or I2S2      | None               | I2S1 or I2S2    |
   | no DAC               |                   |                    | (either-or)     |
   +----------------------+-------------------+--------------------+-----------------+
   | ADC01 only,          | I2S0, I2S2 (in)   | DMIC2, DMIC3       | I2S2 (in)       |
   | with DAC             |                   |                    |                 |
   +----------------------+-------------------+--------------------+-----------------+
   | ADC23 only,          | I2S0, I2S1 or     | DMIC0, DMIC1       | I2S1 or         |
   | with DAC             | I2S2 (in)         |                    | I2S2 (in)       |
   |                      |                   |                    | (either-or)     |
   +----------------------+-------------------+--------------------+-----------------+
   | ADC01+ADC23,         | I2S1 or           | None               | I2S1 or         |
   | with DAC             | I2S2 (in)         |                    | I2S2 (in)       |
   |                      |                   |                    | (either-or)     |
   +----------------------+-------------------+--------------------+-----------------+

Boot Mode
---------

For descriptions of the GPIOB0 and GPIOB1 boot modes, refer to :ref:`Table 4.3 <Table4-2>`.

.. _Table4-2:

.. table:: Boot Mode
    :widths: grid

    +------------+-------------+----------------------+
    | **GPIOB0** | **GPIOB1**  | **Mode Description** |
    +============+=============+======================+
    | 1          | 1           | NOR flash boot       |
    +------------+-------------+----------------------+
    | 1          | 0           | UART                 |
    +------------+-------------+----------------------+
    | 0          | 1           | Reserved             |
    +------------+-------------+----------------------+
    | 0          | 0           | DSP boot only        |
    +------------+-------------+----------------------+

.. Note::
   GPIOA15 (RXD) and GPIOA18 (TXD) are configured as the UART function in the UART boot mode.





