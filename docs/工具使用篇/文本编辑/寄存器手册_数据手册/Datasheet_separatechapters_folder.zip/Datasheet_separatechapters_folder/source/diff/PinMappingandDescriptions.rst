Pin Mapping and Descriptions6011
===================================

Pin Mapping
-------------

For the pin mapping diagram, see :ref:`Fig. 3.1 <3-1>`.

.. _3-1:

.. figure:: ../datasheet_figure/3-1_Pin_Mapping_Diagram.png
   :scale: 40%
   :alt: Pin Mapping Diagram
   :align: center

   Pin Mapping Diagram

Pin Descriptions
----------------

For pin descriptions, refer to :ref:`Table 3.1 <Table3-1>`.

.. _Table3-1:

.. table:: Pin Descriptions
   :widths: grid

   +----------------+--------------------+------------------------------+
   | **Pin Number** | **Pin Name**       | **Description**              |
   +================+====================+==============================+
   | 1              | GPIO_A_14          | Multi-purpose digital I/O.   |
   |                |                    | Refer to 60XX_IOMUX.xlsx     |
   |                |                    | for details.                 |
   +----------------+--------------------+------------------------------+
   | 2              | GPIO_A_15          | Multi-purpose digital I/O.   |
   |                |                    | It supports Boot ROM UART    |
   |                |                    | programming.                 |
   |                |                    | Refer to 60XX_IOMUX.xlsx     |
   |                |                    | for details.                 |
   +----------------+--------------------+------------------------------+
   | 3              | GPIO_A_16          | Multi-purpose digital I/O.   |
   |                |                    | Refer to 60XX_IOMUX.xlsx     |
   |                |                    | for details.                 |
   +----------------+--------------------+------------------------------+
   | 4              | GPIO_A_17          | Multi-purpose digital I/O.   |
   |                |                    | Refer to 60XX_IOMUX.xlsx     |
   |                |                    | for details.                 |
   +----------------+--------------------+------------------------------+
   | 5              | GPIO_A_18          | Multi-purpose digital I/O.   |
   |                |                    | It supports Boot ROM UART    |
   |                |                    | programming.                 |
   |                |                    | Refer to 60XX_IOMUX.xlsx     |
   |                |                    | for details.                 |
   +----------------+--------------------+------------------------------+
   | 6              | GPIO_A_19          | Multi-purpose digital I/O.   |
   |                |                    | Refer to 60XX_IOMUX.xlsx     |
   |                |                    | for details.                 |
   +----------------+--------------------+------------------------------+
   | 7              | GPIO_A_20          | Multi-purpose digital I/O.   |
   |                |                    | Refer to 60XX_IOMUX.xlsx     |
   |                |                    | for details.                 |
   +----------------+--------------------+------------------------------+
   | 8              | GPIO_B_11/USB_DM   | Multi-purpose digital I/O.   |
   |                |                    | Refer to 60XX_IOMUX.xlsx     |
   |                |                    | for details.                 |
   +----------------+--------------------+------------------------------+
   | 9              | GPIO_B_10/USB_DP   | Multi-purpose digital I/O.   |
   |                |                    | Refer to 60XX_IOMUX.xlsx     |
   |                |                    | for details.                 |
   +----------------+--------------------+------------------------------+
   | 10             | VDD_CORE_2         | Connect with VDD_CORE.       |
   +----------------+--------------------+------------------------------+
   | 11             | GPIO_B_08/GPADC_2  | Multi-purpose digital I/O.   |
   |                |                    | Refer to 60XX_IOMUX.xlsx     |
   |                |                    | for details.                 |
   +----------------+--------------------+------------------------------+
   | 12             | GPIO_B_07/GPADC_1  | Multi-purpose digital I/O.   |
   |                |                    | Refer to 60XX_IOMUX.xlsx     |
   |                |                    | for details.                 |
   +----------------+--------------------+------------------------------+
   | 13             | GPIO_B_06/GPADC_0  | Multi-purpose digital I/O.   |
   |                |                    | Refer to 60XX_IOMUX.xlsx     |
   |                |                    | for details.                 |
   +----------------+--------------------+------------------------------+
   | 14             | TST                | Test pin. Default: pull-down.|
   |                |                    | 0: normal mode.              |
   |                |                    | 1: test mode.                |
   +----------------+--------------------+------------------------------+
   | 15             | RESETN             | Reset pin input.             |
   |                |                    | Default: pull-up.            |
   +----------------+--------------------+------------------------------+
   | 16             | GPIO_B_05/KEYSENSE | Multi-purpose digital I/O,   |
   |                |                    | Refer to 60XX_IOMUX.xlsx     |
   |                |                    | for details.                 |
   +----------------+--------------------+------------------------------+
   | 17             | GPIO_B_04          | Multi-purpose digital I/O.   |
   |                |                    | Refer to 60XX_IOMUX.xlsx     |
   |                |                    | for details.                 |
   +----------------+--------------------+------------------------------+
   | 18             | GPIO_B_03          | Multi-purpose digital I/O.   |
   |                |                    | Refer to 60XX_IOMUX.xlsx     |
   |                |                    | for details.                 |
   +----------------+--------------------+------------------------------+
   | 19             | GPIO_B_02/CBT_2    | Multi-purpose digital I/O.   |
   |                |                    | Refer to 60XX_IOMUX.xlsx     |
   |                |                    | for details.                 |
   +----------------+--------------------+------------------------------+
   | 20             | GPIO_B_01/CBT_1    | Multi-purpose digital I/O.   |
   |                |                    | Refer to 60XX_IOMUX.xlsx     |
   |                |                    | for details.                 |
   +----------------+--------------------+------------------------------+
   | 21             | GPIO_B_00/CBT_0    | Multi-purpose digital I/O.   |
   |                |                    | Refer to 60XX_IOMUX.xlsx     |
   |                |                    | for details.                 |
   +----------------+--------------------+------------------------------+
   | 22             | XTAL_OUT           | 24-MHz crystal.              |
   +----------------+--------------------+------------------------------+
   | 23             | XTAL_IN            | 24-MHz crystal.              |
   +----------------+--------------------+------------------------------+
   | 24             | VDD_AON            | Internal LDO output.         |
   |                |                    | Recommended capacitance:     |
   |                |                    | 1 μF.                        |
   +----------------+--------------------+------------------------------+
   | 25             | VCC                | Power input: 2.7 V-5.5 V.    |
   +----------------+--------------------+------------------------------+
   | 26             | VDD_IO             | Internal LDO output.         |
   |                |                    | Recommended capacitance:     |
   |                |                    | 4.7 μF.                      |
   +----------------+--------------------+------------------------------+
   | 27             | AVSS_AUD           | GND.                         |
   +----------------+--------------------+------------------------------+
   | 28             | AVDD_AUD           | Internal LDO output.         |
   |                |                    | Recommended capacitance:     |
   |                |                    | 2.2 μF.                      |
   +----------------+--------------------+------------------------------+
   | 29             | VREF               | Audio codec reference input. |
   +----------------+--------------------+------------------------------+
   | 30             | VMID               | Internal LDO output.         |
   |                |                    | Recommended capacitance:     |
   |                |                    | 4.7 μF.                      |
   +----------------+--------------------+------------------------------+
   | 31             | MICBIAS0           | Microphone bias output.      |
   |                |                    | Recommended capacitance:     |
   |                |                    | 2.2 μF.                      |
   +----------------+--------------------+------------------------------+
   | 32             | MICBIAS1           | Microphone bias output.      |
   |                |                    | Recommended capacitance:     |
   |                |                    | 2.2 μF.                      |
   +----------------+--------------------+------------------------------+
   | 33             | LIN_R_P            | Right channel                |
   |                |                    | differential outputs         |
   |                |                    | positive.                    |
   +----------------+--------------------+------------------------------+
   | 34             | LIN_R_N            | Right channel                |
   |                |                    | differential outputs         |
   |                |                    | negative.                    |
   +----------------+--------------------+------------------------------+
   | 35             | LIN_L_P            | Left channel                 |
   |                |                    | differential outputs         |
   |                |                    | positive.                    |
   +----------------+--------------------+------------------------------+
   | 36             | LIN_L_N            | Left channel                 |
   |                |                    | differential outputs         |
   |                |                    | negative.                    |
   +----------------+--------------------+------------------------------+
   | 37             | MIC0_P             | Microphone input positive.   |
   +----------------+--------------------+------------------------------+
   | 38             | MIC0_N             | Microphone input negative.   |
   +----------------+--------------------+------------------------------+
   | 39             | MIC1_P             | Microphone input positive.   |
   +----------------+--------------------+------------------------------+
   | 40             | MIC1_N             | Microphone input negative.   |
   +----------------+--------------------+------------------------------+
   | 41             | MIC2_P             | Microphone input positive.   |
   +----------------+--------------------+------------------------------+
   | 42             | MIC2_N             | Microphone input negative.   |
   +----------------+--------------------+------------------------------+
   | 43             | MIC3_P             | Microphone input positive.   |
   +----------------+--------------------+------------------------------+
   | 44             | MIC3_N             | Microphone input negative.   |
   +----------------+--------------------+------------------------------+
   | 45             | VDD_CORE           | Internal LDO output.         |
   |                |                    | Recommended capacitance:     |
   |                |                    | 4.7 μF.                      |
   |                |                    | Connect with VDD_CORE_2.     |
   +----------------+--------------------+------------------------------+
   | 46             | VDD_IO2            | Internal DC-DC input.        |
   |                |                    | Recommended  capacitance:    |
   |                |                    | 10 μF.                       |
   +----------------+--------------------+------------------------------+
   | 47             | VBK_PVSS           | DC-DC GND.                   |
   +----------------+--------------------+------------------------------+
   | 48             | VBK_SW             | DC-DC switch out. Connected  |
   |                |                    | with a 3.3-μH inductor.      |
   +----------------+--------------------+------------------------------+
   | 49             | VBK_IN             | DC-DC input power:           |
   |                |                    | 2.7 V-5.5 V.                 |           
   +----------------+--------------------+------------------------------+
   | 50             | GPIO_A_00/SWDCLK   | Multi-purpose digital I/O.   |
   |                |                    | Refer to 60XX_IOMUX.xlsx     |
   |                |                    | for details.                 |
   +----------------+--------------------+------------------------------+
   | 51             | GPIO_A_01/SWDTMS   | Multi-purpose digital I/O.   |
   |                |                    | Refer to 60XX_IOMUX.xlsx     |
   |                |                    | for details.                 |
   +----------------+--------------------+------------------------------+
   | 52             | GPIO_A_02          | Multi-purpose digital I/O.   |
   |                |                    | Refer to 60XX_IOMUX.xlsx     |
   |                |                    | for details.                 |
   +----------------+--------------------+------------------------------+
   | 53             | GPIO_A_03          | Multi-purpose digital I/O.   |
   |                |                    | Refer to 60XX_IOMUX.xlsx     |
   |                |                    | for details.                 |
   +----------------+--------------------+------------------------------+
   | 54             | FLASH_WP_N         | Connect with an external     |
   |                |                    | QSPI flash.                  |
   +----------------+--------------------+------------------------------+
   | 55             | FLASH_MISO         | Connect with an external     |
   |                |                    | QSPI flash.                  |
   +----------------+--------------------+------------------------------+
   | 56             | FLASH_CS_N         | Connect with an external     |
   |                |                    | QSPI flash.                  |
   +----------------+--------------------+------------------------------+
   | 57             | VDD_IO_1           | Input power. Connect with    |
   |                |                    | VDD_IO.                      |
   +----------------+--------------------+------------------------------+
   | 58             | FLASH_HOLD_N       | Connect with an external     |
   |                |                    | QSPI flash.                  |
   +----------------+--------------------+------------------------------+
   | 59             | FLASH_CLK          | Connect with an external     |
   |                |                    | QSPI flash.                  |
   +----------------+--------------------+------------------------------+
   | 60             | FLASH_MOSI         | Connect with an external     |
   |                |                    | QSPI flash.                  |
   +----------------+--------------------+------------------------------+
   | 61             | GPIO_A_10          | Multi-purpose digital I/O.   |
   |                |                    | Refer to 60XX_IOMUX.xlsx     |
   |                |                    | for details.                 |
   +----------------+--------------------+------------------------------+
   | 62             | GPIO_A_11          | Multi-purpose digital I/O.   |
   |                |                    | Refer to 60XX_IOMUX.xlsx     |
   |                |                    | for details.                 |
   +----------------+--------------------+------------------------------+
   | 63             | GPIO_A_12          | Multi-purpose digital I/O.   |
   |                |                    | Refer to 60XX_IOMUX.xlsx     |
   |                |                    | for details.                 |
   +----------------+--------------------+------------------------------+
   | 64             | GPIO_A_13          | Multi-purpose digital I/O.   |
   |                |                    | Refer to 60XX_IOMUX.xlsx     |
   |                |                    | for details.                 |
   +----------------+--------------------+------------------------------+
   | 65             | EPAD               | Connect with GND.            |
   +----------------+--------------------+------------------------------+

.. Note::   
   The pull-up resistor resistance is set to 80 K. 





