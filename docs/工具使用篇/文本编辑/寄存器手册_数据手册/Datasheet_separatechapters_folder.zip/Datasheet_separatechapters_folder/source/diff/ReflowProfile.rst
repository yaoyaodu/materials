Reflow Profile6011
========================

Reflow Diagram
-----------------

For the reflow diagram, see :ref:`Fig. 7.1 <7-1>`.

.. _7-1:

.. figure:: ../datasheet_figure/7-1_Reflow_Diagram.png
   :scale: 45%
   :align: center

   Reflow Diagram

SMT Reflow Conditions
--------------------------

.. _Table7-1:

.. table:: Reflow Parameter Descriptions
   :widths: grid

   +----------------------------------+----------------------------------+
   | **Parameter**                    | **Requirement**                  |
   +==================================+==================================+
   | N2 purge reflow usage            | Yes                              |
   +----------------------------------+----------------------------------+
   | O2 ppm level                     | < 1500 ppm                       |
   +----------------------------------+----------------------------------+
   | Temperature Min (T\ :sub:`smin`) | 150 °C                           |
   +----------------------------------+----------------------------------+
   | Temperature Max (T\ :sub:`smax`) | 200 °C                           |
   +----------------------------------+----------------------------------+
   | Time                             | 60-120 seconds                   |
   | (t\ :sub:`s`)from(T\ :sub:`smin` |                                  |
   | to T\ :sub:`smax`)               |                                  |
   +----------------------------------+----------------------------------+
   | Ramp-up rate (T\ :sub:`L` to     | 3 °C/second maximumly            |
   | T\ :sub:`P`)                     |                                  |
   +----------------------------------+----------------------------------+
   | Liquidous                        | 217 °C                           |
   | temperature (T\ :sub:`L` )       |                                  |
   +----------------------------------+----------------------------------+
   | Time(t\ :sub:`L`) maintained     | 60-150 seconds                   |
   | above T\ :sub:`L`                |                                  |
   +----------------------------------+----------------------------------+
   | Peak package body                | Tp must not exceed the           |
   | temperature (T\ :sub:`P`)        | Classification                   |
   |                                  | temp (T\ :sub:`C`\ ) in table    |
   |                                  | below                            |
   +----------------------------------+----------------------------------+
   | Time(t\ :sub:`p`)within 5 °C of  | 30 seconds maximumly             |
   | the specified classification     |                                  |
   | temperature (T\ :sub:`C`)        |                                  |
   +----------------------------------+----------------------------------+
   | Ramp-down rate (T\ :sub:`P` to   | 6 °C/second maximumly            |
   | T\ :sub:`L`)                     |                                  |
   +----------------------------------+----------------------------------+
   | Time 25 °C to peak temperature   | 8 minutes maximumly              | 
   +----------------------------------+----------------------------------+

.. _Table7-2:

.. table:: Corresponding Relationshiop among Thickness, Volume, and Temperature
   :widths: grid

   +----------------+----------------+----------------+----------------+
   | **Package      | **Volume mm3   | **Volume mm3   | **Volume mm3   |
   | Thickness**    | < 350**        | 350-2000**     | > 2000**       |
   +================+================+================+================+
   | < 1.6 mm       | 260 °C         | 260 °C         | 260 °C         |
   +----------------+----------------+----------------+----------------+
   | 1.6 mm-2.5 mm  | 260 °C         | 250 °C         | 245 °C         |
   +----------------+----------------+----------------+----------------+
   | > 2.5 mm       | 250 °C         | 245 °C         | 245 °C         |
   +----------------+----------------+----------------+----------------+





