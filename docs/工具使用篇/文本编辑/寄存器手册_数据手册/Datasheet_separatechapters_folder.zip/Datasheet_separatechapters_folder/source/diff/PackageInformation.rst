Package Information6011
=============================

QFN64 (8*8 mm) Package Information
-----------------------------------

For the package information, see :ref:`Fig. 6.1 <6-1>`, :ref:`Fig. 6.2 <6-2>`, and :ref:`Figure 6-3 <6-3>`.

.. _6-1:

.. figure:: ../datasheet_figure/6-1_Top_View.png
   :scale: 65%
   :align: center

   Top View

.. _6-2:

.. figure:: ../datasheet_figure/6-2_Bottom_View.png
   :scale: 65%
   :align: center

   Bottom View


.. _6-3:

.. figure:: ../datasheet_figure/6-3.png
   :scale: 65%
   :align: center

   Symbol Dimension

Thermal Characteristics
-----------------------

The maximum chip junction temperature (T\ :sub:`J`\max) in degrees
Celsius can be calculated through the following equation:

.. math::    
   T_J max = T_A max + (P_D max * \theta_{JA})   

where:

-  T\ :sub:`A`\max is the maximum ambient temperature in °C.

-  θ\ :sub:`JA` is the package junction-to-ambient thermal resistance in °C/W.

-  P\ :sub:`D`\max is the sum of P\ :sub:`INT`\max and P\ :sub:`I/O`\max
   (P\ :sub:`D`\max = P\ :sub:`INT`\max + P\ :sub:`I/O`\max).

-  P\ :sub:`INT`\max is the product of I\ :sub:`DD` and V\ :sub:`DD` in Watts. 
   This is the maximum chip internal power.

P\ :sub:`I/O`\max represents the maximum power dissipation on output pins and can be 
calculated through the following equation:

.. math::
   P_{I/O} max = \sum (V_{OL} * I_{OL}) + ((V_{DD} – V_{OH}) * I_{OH})

The actual V\ :sub:`OL`/I\ :sub:`OL` and V\ :sub:`OH`/I\ :sub:`OH` of the I/Os at
low and high levels in the application are taken into account.

.. _Table6-1:

.. table:: Package Thermal Characteristics
   :widths: grid

   +---------------+-----------------------------------------+----------------+----------+
   | **Symbol**    | **Parameter**                           | **Value**      | **Unit** |
   +===============+=========================================+================+==========+
   | θ\ :sub:`JA`  | Junction-to-ambient thermal resistance  | 28             | °C/W     |
   |               |                                         |                |          |
   |               | QFN64 – 8*8 mm                          |                |          |
   +---------------+-----------------------------------------+----------------+----------+
   | T\ :sub:`STG` | Storage temperature range               | –65 to +150    | °C       |
   +---------------+-----------------------------------------+----------------+----------+
   | T\ :sub:`J`   | Maximum junction temperature            | 125            | °C       |
   +---------------+-----------------------------------------+----------------+----------+







