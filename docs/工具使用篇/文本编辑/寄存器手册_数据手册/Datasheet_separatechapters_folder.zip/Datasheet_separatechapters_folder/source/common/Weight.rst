Weight
======

The SoC weighs 200 mg.





