Application Diagram
===================
For the application diagram, see :ref:`Fig. 9.1 <9-1>`.

.. _9-1:

.. figure:: ../datasheet_figure/9-1_Application_Diagram.png
   :scale: 50%
   :align: center

   Application Diagram





