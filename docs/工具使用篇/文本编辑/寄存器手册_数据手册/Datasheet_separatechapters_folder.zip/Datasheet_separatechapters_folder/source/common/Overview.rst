Overview
==============

The CSK6 serial is a dual-core microcontroller embedded with an ARM STAR core and
a HiFi4 core. The ARM Star core is designed for 32-bit microcontroller
applications, offering high performance, low power, simple instruction set
and addressing together with reduced code size compared with exiting
solutions. The HiFi4 core is designed for audio coders and decoders such as MP3,
AAC, and FLAC. The independent NPU is designed for neural network operation.

The CSK6 serial applies for smart home appliances.

The CSK6 serial can operate up to 300 MHz. Thus it can afford to support a
variety of industrial control and applications that require high CPU
performance. The CSK6 serial has a built-in 1-MB data SRAM.

The CSK6 serial supports many system-level peripheral functions, such as IO port, DVP, timer,
watchdog timer, UART, SPI, I2C, DMA, PLL, USB1.1 (full speed), RTC, and SDIO.





