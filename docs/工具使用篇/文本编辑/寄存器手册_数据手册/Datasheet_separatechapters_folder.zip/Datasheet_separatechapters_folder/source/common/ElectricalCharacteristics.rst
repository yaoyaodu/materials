Electrical Characteristics
==========================

Parameter Conditions
--------------------

Unless otherwise specified, all voltages are referred to as V\ :sub:`SS`\.

Minimum and Maximum Values
~~~~~~~~~~~~~~~~~~~~~~~~~~

Unless otherwise specified the minimum and maximum values are guaranteed
in the worst conditions of ambient temperature, supply voltage and
frequencies during test in production on 100% of the devices with an
ambient temperature at 25 °C and the maximum temperature in the range.

Data based on characterization results, design simulation and/or
technology characteristics are indicated in the table footnotes and are
not tested in production. Based on characterization, the minimum and
maximum values are based on sample tests and represent the mean value plus
or minus three times the standard deviation (mean ± 3σ).

Typical Values
~~~~~~~~~~~~~~

Unless otherwise specified, typical data is based on T\ :sub:`A` = 25 °C, V\ :sub:`CCIN`
= 5 V (voltage range: 2.7 V :math:`\leqslant` V\ :sub:`CCIN` :math:`\leqslant` 5 V). They are given only
as design guidelines and are not tested.

Loading Capacitor
~~~~~~~~~~~~~~~~~

The loading capacitor used for pin parameter measurement is 10 pf.

Pin Input Voltage
~~~~~~~~~~~~~~~~~

The input voltage measurement on a pin of the device is through the current source device.

Operation Conditions
--------------------

Absolute Maximum Ratings
~~~~~~~~~~~~~~~~~~~~~~~~

For information about voltage characteristics, refer to :ref:`Table 5.1 <Table5-1>`.

.. _Table5-1:

.. table:: Voltage Characteristics
    :widths: grid

    +----------------------------------+------------------------+----------+---------+----------+
    | **Symbol**                       | **Ratings**            | **Min**  | **Max** | **Unit** |
    +==================================+========================+==========+=========+==========+
    | V\ :sub:`CCIN`-V\ :sub:`SS`      | External supply        | -0.3     | 5.5     | V        |
    |                                  | voltage                |          |         |          |
    +----------------------------------+------------------------+----------+---------+----------+
    | V\ :sub:`IL`                     | Low-level input        | -0.3     | 0.8     | V        |
    |                                  | voltage on signal pins |          |         |          |
    +----------------------------------+------------------------+----------+---------+----------+
    | V\ :sub:`IH`                     | High-level input       | 2        | 5.5     | V        |
    |                                  | voltage on signal pins |          |         |          |
    |                                  | (port A)               |          |         |          |
    +----------------------------------+------------------------+----------+---------+----------+
    | V\ :sub:`IH`                     | High-level input       | 2        | 3.6     | V        |
    |                                  | voltage on signal pins |          |         |          |
    |                                  | (port B)               |          |         |          |
    +----------------------------------+------------------------+----------+---------+----------+
    | V\ :sub:`OL`                     | Low-level output       |          | 0.4     | V        |
    |                                  | voltage on signal pins |          |         |          |
    +----------------------------------+------------------------+----------+---------+----------+
    | V\ :sub:`OH`                     | High-level output      | 2.4      |         | V        |
    |                                  | voltage on signal pins |          |         |          |
    +----------------------------------+------------------------+----------+---------+----------+


I/O Port Characteristics
~~~~~~~~~~~~~~~~~~~~~~~~

For information about I/O Static characteristics, refer to :ref:`Table 5.2 <Table5-2>`.

.. _Table5-2:

.. table:: I/O Static Characteristics

   +---------------+---------------+-------------------+----------+----------+-----------+----------+
   | **Symbol**    | **Parameter** | **Conditions**    | **Min**  | **Typ**  | **Max**   | **Unit** |
   +===============+===============+===================+==========+==========+===========+==========+
   | V\ :sub:`IL`  | Standard IO   | 2.7 V             | -0.3     |          | 0.8       | V        |
   |               | low-level     | :math:`\leqslant` |          |          |           |          |
   |               | input         | V\ :sub:`CCIN`    |          |          |           |          |
   |               | voltage       | :math:`\leqslant` |          |          |           |          |
   |               |               | 5.5 V             |          |          |           |          |
   |               |               |                   |          |          |           |          |
   |               |               | T\ :sub:`A`       |          |          |           |          |
   |               |               | = 25 °C           |          |          |           |          |
   +---------------+---------------+-------------------+----------+----------+-----------+----------+
   | V\ :sub:`IH`  | Standard IO   | 2.7 V             | 2        |          | 5.5       | V        |
   |               | high-level    | :math:`\leqslant` |          |          |           |          |
   |               | input         | V\ :sub:`CCIN`    |          |          |           |          |
   |               | voltage       | :math:`\leqslant` |          |          |           |          |
   |               | (port A)      | 5.5 V             |          |          |           |          |
   |               |               |                   |          |          |           |          |
   |               |               | T\ :sub:`A`       |          |          |           |          |
   |               |               | = 25 °C           |          |          |           |          |
   +---------------+---------------+-------------------+----------+----------+-----------+----------+
   | V\ :sub:`IH`  | Standard IO   | 2.7 V             | 2        |          | 3.6       | V        |
   |               | high-level    | :math:`\leqslant` |          |          |           |          |
   |               | input         | V\ :sub:`CCIN`    |          |          |           |          |
   |               | voltage       | :math:`\leqslant` |          |          |           |          |
   |               | (port B)      | 5.5 V             |          |          |           |          |
   |               |               |                   |          |          |           |          |
   |               |               | T\ :sub:`A`       |          |          |           |          |
   |               |               | = 25 °C           |          |          |           |          |
   +---------------+---------------+-------------------+----------+----------+-----------+----------+
   | V\ :sub:`hys` | Standard IO   | 2.7 V             |          | 220      |           | mV       |
   |               | Schmitt       | :math:`\leqslant` |          |          |           |          |
   |               | trigger       | V\ :sub:`CCIN`    |          |          |           |          |
   |               | voltage       | :math:`\leqslant` |          |          |           |          |
   |               | hysteresis    | 5.5 V             |          |          |           |          |
   |               |               |                   |          |          |           |          |
   |               |               | T\ :sub:`A`       |          |          |           |          |
   |               |               | = 25 °C           |          |          |           |          |
   +---------------+---------------+-------------------+----------+----------+-----------+----------+
   | V\ :sub:`OL`  | Low-level     | 2.7 V             |          |          | 0.4       | V        |
   |               | output        | :math:`\leqslant` |          |          |           |          |
   |               | voltage       | V\ :sub:`CCIN`    |          |          |           |          |
   |               |               | :math:`\leqslant` |          |          |           |          |
   |               |               | 5.5 V             |          |          |           |          |
   |               |               |                   |          |          |           |          |
   |               |               | T\ :sub:`A`       |          |          |           |          |
   |               |               | = 25 °C           |          |          |           |          |
   +---------------+---------------+-------------------+----------+----------+-----------+----------+
   | V\ :sub:`OH`  | High-level    | 2.7 V             | 2.4      |          |           | V        |
   |               | output        | :math:`\leqslant` |          |          |           |          |
   |               | voltage       | V\ :sub:`CCIN`    |          |          |           |          |
   |               |               | :math:`\leqslant` |          |          |           |          |
   |               |               | 5.5 V             |          |          |           |          |
   |               |               |                   |          |          |           |          |
   |               |               | T\ :sub:`A`       |          |          |           |          |
   |               |               | = 25 °C           |          |          |           |          |
   +---------------+---------------+-------------------+----------+----------+-----------+----------+
   | I\ :sub:`OL`  | Low-level     | 2.7 V             |          | 15       |           | mA       |
   |               | output        | :math:`\leqslant` |          |          |           |          |
   |               | current       | V\ :sub:`CCIN`    |          |          |           |          |
   |               |               | :math:`\leqslant` |          |          |           |          |
   |               |               | 5.5 V             |          |          |           |          |
   |               |               |                   |          |          |           |          |
   |               |               | T\ :sub:`A`       |          |          |           |          |
   |               |               | = 25 °C           |          |          |           |          |
   +---------------+---------------+-------------------+----------+----------+-----------+----------+
   | I\ :sub:`OH`  | High-level    | 2.7 V             |          | 22       |           | mA       |
   |               | output        | :math:`\leqslant` |          |          |           |          |
   |               | current       | V\ :sub:`CCIN`    |          |          |           |          |
   |               |               | :math:`\leqslant` |          |          |           |          |
   |               |               | 5.5 V             |          |          |           |          |
   |               |               |                   |          |          |           |          |
   |               |               | T\ :sub:`A`       |          |          |           |          |
   |               |               | = 25 °C           |          |          |           |          |
   +---------------+---------------+-------------------+----------+----------+-----------+----------+
   | I\ :sub:`Ikg` | Input         | 2.7 V             |          | 1        |           | μA       |
   |               | leakage       | :math:`\leqslant` |          |          |           |          |
   |               | current       | V\ :sub:`CCIN`    |          |          |           |          |
   |               |               | :math:`\leqslant` |          |          |           |          |
   |               |               | 5.5 V             |          |          |           |          |
   |               |               |                   |          |          |           |          |
   |               |               | T\ :sub:`A`       |          |          |           |          |
   |               |               | = 25 °C           |          |          |           |          |
   +---------------+---------------+-------------------+----------+----------+-----------+----------+
   | R\ :sub:`PU`  | Pull-up       |                   | 74 k     | 80 k     | 158 k     | Ω        |
   |               | equivalent    |                   |          |          |           |          |
   |               | resistor      |                   |          |          |           |          |
   +---------------+---------------+-------------------+----------+----------+-----------+----------+
   | R\ :sub:`PD`  | Pull-down     |                   | 62 k     | 75 k     | 203 k     | Ω        |
   |               | equivalent    |                   |          |          |           |          |
   |               | resistor      |                   |          |          |           |          |
   +---------------+---------------+-------------------+----------+----------+-----------+----------+
   | C\ :sub:`IO`  | I/O pin       |                   |          | 5        |           | pF       |
   |               | capacitance   |                   |          |          |           |          |
   +---------------+---------------+-------------------+----------+----------+-----------+----------+

.. Note::
   Only port A is a 5-V tolerance IO and the input voltage can be 5.5 V maximumly.

IO AC Characteristics
~~~~~~~~~~~~~~~~~~~~~

For information about I/O AC characteristics, refer to :ref:`Table 5.3 <Table5-3>`.

.. _Table5-3:

.. table:: IO AC Characteristics
   :widths: grid

   +----------------------+------------------+---------------------+---------+---------+---------+----------+
   | **Symbol**           | **Parameter**    | **Conditions**      | **Min** | **Typ** | **Max** | **Unit** |
   +======================+==================+=====================+=========+=========+=========+==========+
   | F\ :sub:`max(io)out` | Maximum          | 2.7 V               |         | 100     |         | MHz      |
   |                      | frequency        | :math:`\leqslant`   |         |         |         |          |
   |                      |                  | V\ :sub:`CCIN`      |         |         |         |          |
   |                      |                  | :math:`\leqslant`   |         |         |         |          |
   |                      |                  | 5.5 V               |         |         |         |          |
   |                      |                  |                     |         |         |         |          |
   |                      |                  | T\ :sub:`A`         |         |         |         |          |
   |                      |                  | = 25 °C             |         |         |         |          |
   |                      |                  |                     |         |         |         |          |
   |                      |                  | C\ :sub:`L` = 10 pf |         |         |         |          |
   +----------------------+------------------+---------------------+---------+---------+---------+----------+
   | T\ :sub:`f(IO)out`   | Fall time        | 2.7 V               |         | 2.5     |         | ns       |
   |                      | and              | :math:`\leqslant`   |         |         |         |          |
   |                      | rise time        | V\ :sub:`CCIN`      |         |         |         |          |
   |                      |                  | :math:`\leqslant`   |         |         |         |          |
   |                      |                  | 5.5 V               |         |         |         |          |
   |                      |                  |                     |         |         |         |          |
   |                      |                  | T\ :sub:`A`         |         |         |         |          |
   |                      |                  | = 25 °C             |         |         |         |          |
   |                      |                  |                     |         |         |         |          |
   |                      |                  | C\ :sub:`L` = 10 pf |         |         |         |          |
   +                      +                  +---------------------+---------+---------+---------+----------+
   |                      |                  | 2.7 V               |         | 2.5     |         | ns       |
   |                      |                  | :math:`\leqslant`   |         |         |         |          |
   |                      |                  | V\ :sub:`CCIN`      |         |         |         |          |
   |                      |                  | :math:`\leqslant`   |         |         |         |          |
   |                      |                  | 5.5 V               |         |         |         |          |
   |                      |                  |                     |         |         |         |          |
   |                      |                  | T\ :sub:`A`         |         |         |         |          |
   |                      |                  | = 25 °C             |         |         |         |          |
   |                      |                  |                     |         |         |         |          |
   |                      |                  | C\ :sub:`L` = 10 pf |         |         |         |          |
   +----------------------+------------------+---------------------+---------+---------+---------+----------+

nRESET Pin Characteristics
~~~~~~~~~~~~~~~~~~~~~~~~~~

For information about nRESET pin characteristics, refer to :ref:`Table 5.4 <Table5-4>`.

.. _Table5-4:

.. table:: nRESET Pin Characteristics
   :widths: grid

   +--------------------+-------------------+-------------------+---------+---------+---------+----------+
   | **Symbol**         | **Parameter**     | **Conditions**    | **Min** | **Typ** | **Max** | **Unit** |
   +====================+===================+===================+=========+=========+=========+==========+
   | R\ :sub:`PU`       | Pull-up           | 2.7 V             |         | 80 k    |         | Ω        |
   |                    | equivalent        | :math:`\leqslant` |         |         |         |          |
   |                    | resistor          | V\ :sub:`CCIN`    |         |         |         |          |
   |                    |                   | :math:`\leqslant` |         |         |         |          |
   |                    |                   | 5.5 V             |         |         |         |          |
   |                    |                   |                   |         |         |         |          |
   |                    |                   | T\ :sub:`A`       |         |         |         |          |
   |                    |                   | = 25 °C           |         |         |         |          |
   +--------------------+-------------------+-------------------+---------+---------+---------+----------+
   | T\ :sub:`(nRESET)` | nRESET input      | 2.7 V             |         | 1       |         | ms       |
   |                    | pulse             | :math:`\leqslant` |         |         |         |          |
   |                    |                   | V\ :sub:`CCIN`    |         |         |         |          |
   |                    |                   | :math:`\leqslant` |         |         |         |          |
   |                    |                   | 5.5 V             |         |         |         |          |
   |                    |                   |                   |         |         |         |          |
   |                    |                   | T\ :sub:`A`       |         |         |         |          |
   |                    |                   | = 25 °C           |         |         |         |          |
   |                    |                   |                   |         |         |         |          |
   |                    |                   | C\ :sub:`L`       |         |         |         |          |
   |                    |                   | = 10 pf           |         |         |         |          |
   +--------------------+-------------------+-------------------+---------+---------+---------+----------+

Supply Current Characteristics
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

For information about supply current characteristics, refer to :ref:`Table 5.5 <Table5-5>`.

.. _Table5-5:

.. table:: Supply Current Characteristics
   :widths: grid

   +--------------+---------------+-----------------+---------------------+-------------+----------+
   | **Symbol**   | **Parameter** | **Conditions**  | f\ :sub:`sysclk`    | **Typical** | **Unit** |
   |              |               |                 | **(MHz)**           |             |          |
   +==============+===============+=================+=====================+=============+==========+
   | I\ :sub:`DD` | Supply        | V\ :sub:`CCIN`  | 100                 | 20          | mA       |
   |              | current       | = 5 V,          |                     |             |          |
   |              | in RUN        | external        |                     |             |          |
   |              | mode          | 24-MHz crystal  |                     |             |          |
   |              |               |                 |                     |             |          |
   |              |               | T\ :sub:`A`     |                     |             |          |
   |              |               | = 25 °C,        |                     |             |          |
   |              |               | PLL ON,         |                     |             |          |
   |              |               |                 |                     |             |          |
   |              |               | AP ON, CP       |                     |             |          |
   |              |               | ON, NPU ON      |                     |             |          |
   |              |               |                 |                     |             |          |
   |              |               | PSRAM           |                     |             |          |
   |              |               | off, NOR        |                     |             |          |
   |              |               | flash           |                     |             |          |
   |              |               | cached          |                     |             |          |
   |              +---------------+-----------------+---------------------+-------------+----------+
   |              | Supply        | T\ :sub:`A`     | 24                  | 1.8         | mA       |
   |              | current       | = 25 °C,        |                     |             |          |
   |              | in            | deep            |                     |             |          |
   |              | VAD&          | sleep           |                     |             |          |
   |              | DEEPSLEEP     | mode            |                     |             |          |
   |              | mode          | entered,        |                     |             |          |
   |              |               | VAD mode        |                     |             |          |
   |              |               | enabled         |                     |             |          |
   |              |               | with 1          |                     |             |          |
   |              |               | audio ADC       |                     |             |          |
   |              |               | on (analog      |                     |             |          |
   |              |               | mic not         |                     |             |          |
   |              |               | included)       |                     |             |          |
   |              +---------------+-----------------+---------------------+-------------+----------+
   |              | Supply        | T\ :sub:`A`     | 24                  | 700         | μA       |
   |              | current       | = 25 °C,        |                     |             |          |
   |              | in            | deep            |                     |             |          |
   |              | DEEPSLEEP     | sleep           |                     |             |          |
   |              | mode          | mode            |                     |             |          |
   |              |               | entered         |                     |             |          |
   +--------------+---------------+-----------------+---------------------+-------------+----------+

Wake-up Time from the Sleep Mode
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

For information about wake-up time from the sleep mode, refer to :ref:`Table 5.6 <Table5-6>`.

.. _Table5-6:

.. table:: Wakeup Time from Sleep Modes
   :widths: grid

   +-------------------+----------------+----------------+-------------+----------+
   | **Symbol**        | **Parameter**  | **Conditions** | **Typical** | **Unit** |
   +===================+================+================+=============+==========+
   | t\ :sub:`WUSLEEP` | Wakeup from    | External pin   | < 2         | ms       |
   |                   | sleep          | wake-up (ROM   |             |          |
   |                   |                | boot not       |             |          |
   |                   |                | included)      |             |          |
   +-------------------+----------------+----------------+-------------+----------+

External Clock Source Characteristics
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

For information about external clock source characteristics, refer to :ref:`Table 5.7 <Table5-7>`.

.. _Table5-7:

.. table:: External Clock Source Characteristics
   :widths: grid

   +--------------------+----------------+----------------+---------+---------+---------+----------+
   | **Symbol**         | **Parameter**  | **Conditions** | **Min** | **Typ** | **Max** | **Unit** |
   +====================+================+================+=========+=========+=========+==========+
   | f\ :sub:`osc`      | External       |                |         | 24      |         | MHz      |
   |                    | clock source   |                |         |         |         |          |
   |                    | frequency      |                |         |         |         |          |
   +--------------------+----------------+----------------+---------+---------+---------+----------+
   | V\ :sub:`OSCH`     | OSC in input   |                |         | 3.3     |         | V        |
   |                    | pin high       |                |         |         |         |          |
   |                    | level          |                |         |         |         |          |
   |                    | voltage        |                |         |         |         |          |
   +--------------------+----------------+----------------+---------+---------+---------+----------+
   | V\ :sub:`OSCL`     | OSC in input   |                |         | 0       |         | V        |
   |                    | pin low        |                |         |         |         |          |
   |                    | level          |                |         |         |         |          |
   |                    | voltage        |                |         |         |         |          |
   +--------------------+----------------+----------------+---------+---------+---------+----------+
   | C\ :sub:`IN(OSC)`  | OSC in input   |                |         | 5       |         | pF       |
   |                    | capacitance    |                |         |         |         |          |
   +--------------------+----------------+----------------+---------+---------+---------+----------+
   | Ducy\ :sub:`(OSC)` | Duty cycle     |                | 45      |         | 55      | %        |
   |                    |                |                |         |         |         |          |
   +--------------------+----------------+----------------+---------+---------+---------+----------+
   | I\ :sub:`L`        | OSC IN input   |                |         | 430     |         | μA       |
   |                    | leakage        |                |         |         |         |          |
   |                    | current        |                |         |         |         |          |
   +--------------------+----------------+----------------+---------+---------+---------+----------+

Internal Clock Source Characteristics
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

For information about internal clock source characteristics, refer to :ref:`Table 5.8 <Table5-8>`.

.. _Table5-8:

.. table:: Internal Clock Source Characteristics
   :widths: grid

   +-------------------+---------------+-------------------------+---------+---------+---------+----------+
   | **Symbol**        | **Parameter** | **Conditions**          | **Min** | **Typ** | **Max** | **Unit** |
   +===================+===============+=========================+=========+=========+=========+==========+
   | f\ :sub:`LSI`     | Frequency     | 2.7 V :math:`\leqslant` |         | 32      |         | KHz      |
   |                   |               | V\ :sub:`CCIN`          |         |         |         |          |
   |                   |               | :math:`\leqslant` 5.5 V |         |         |         |          |
   |                   |               |                         |         |         |         |          |
   |                   |               | T\ :sub:`A`             |         |         |         |          |
   |                   |               | = 25 °C                 |         |         |         |          |
   +-------------------+---------------+-------------------------+---------+---------+---------+----------+
   | t\ :sub:`su(LSI)` | LSI           | 2.7 V :math:`\leqslant` |         | 5       |         | s        |
   |                   | oscillator    | V\ :sub:`CCIN`          |         |         |         |          |
   |                   | start-up      | :math:`\leqslant` 5.5 V |         |         |         |          |
   |                   | time          |                         |         |         |         |          |
   |                   |               | T\ :sub:`A`             |         |         |         |          |
   |                   |               | = 25 °C                 |         |         |         |          |
   +-------------------+---------------+-------------------------+---------+---------+---------+----------+
   | I\ :sub:`DD(LSI)` | LSI           | 2.7 V :math:`\leqslant` |         |         | 1       | μA       |
   |                   | oscillator    | V\ :sub:`CCIN`          |         |         |         |          |
   |                   | power         | :math:`\leqslant` 5.5 V |         |         |         |          |
   |                   | consumption   |                         |         |         |         |          |
   |                   |               | T\ :sub:`A`             |         |         |         |          |
   |                   |               | = 25 °C                 |         |         |         |          |
   +-------------------+---------------+-------------------------+---------+---------+---------+----------+

PLL Characteristics
~~~~~~~~~~~~~~~~~~~

For information about PLL characteristics, refer to :ref:`Table 5.9 <Table5-9>`.

.. _Table5-9:

.. table:: PLL Characteristics
   :widths: grid

   ================= ===================== ============== ======= ======= ======= ========
   **Symbol**        **Parameter**         **Conditions** **Min** **Typ** **Max** **Unit**
   ================= ===================== ============== ======= ======= ======= ========
   f\ :sub:`PLL_IN`  PLL input clock                              24              MHz
   f\ :sub:`PLL_OUT` PLL output clock                             300             MHz
   Jitter            Cycle-to cycle jitter                        10              ps
   ================= ===================== ============== ======= ======= ======= ========

EMC
~~~

For information about Electromagnetic Compatibility (EMC), refer to :ref:`Table 5.10 <Table5-10>`.

.. _Table5-10:

.. table:: EMC
   :widths: grid

   +------------+-------------+-----------------+-----------+-----------+----------+
   | **Symbol** | **Ratings** | **Conditions**  | **Class** | **Maximum | **Unit** |
   |            |             |                 |           | Value**   |          |
   +============+=============+=================+===========+===========+==========+
   | VESD (HBM) | Elec        | T\ :sub:`A`     | 2         | 2000      | V        |
   |            | trostatic   | = 25 °C         |           |           |          |
   |            | discharge   |                 |           |           |          |
   |            | voltage     |                 |           |           |          |
   |            | (human      |                 |           |           |          |
   |            | body        |                 |           |           |          |
   |            | model)      |                 |           |           |          |
   +------------+-------------+-----------------+-----------+-----------+----------+
   | VESD (CDM) | Elec        | T\ :sub:`A`     |           | 1000      | V        |
   |            | trostatic   | = 25 °C         |           |           |          |
   |            | discharge   |                 |           |           |          |
   |            | voltage     |                 |           |           |          |
   |            | (charge     |                 |           |           |          |
   |            | device      |                 |           |           |          |
   |            | model)      |                 |           |           |          |
   +------------+-------------+-----------------+-----------+-----------+----------+





