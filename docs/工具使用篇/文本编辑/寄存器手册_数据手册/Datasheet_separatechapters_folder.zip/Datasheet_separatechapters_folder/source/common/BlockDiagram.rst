Block Diagram
==============

For the block diagram, see :ref:`Fig. 2.1 <2-1>`.

.. _2-1:

.. figure:: ../datasheet_figure/2-1_Block_Diagram.png
   :scale: 40%
   :alt: Block Diagram
   :align: center

   Block Diagram





