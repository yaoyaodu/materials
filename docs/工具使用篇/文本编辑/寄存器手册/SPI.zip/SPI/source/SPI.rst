Introduction 
~~~~~~~~~~~~~~~~~~~

AndeShape™ ATCSPI200 is a Serial Peripheral Interface (SPI) controller
which serves as a SPI master or a SPI slave. As a SPI master, the
controller connects various SPI devices. As a SPI slave, the controller
responds to the master requests for data exchange.

Main Features 
~~~~~~~~~~~~~~~~

-  AMBA™ AHB/APB 2.0 compliant

-  Support for MSB/LSB first transfer

-  Support for Direct Memory Access (DMA) data transfer

-  Support for programmable SPI SCLK

-  Support for memory mapped access (read-only) through AHB bus or EILM
   bus

-  Support for SPI slave mode

-  Configurable Dual and Quad I/O SPI interfaces

-  Configurable TX/RX FIFO depth (The depth could be 2, 4, 8 or 16)

-  Configurable programming port location on AHB/APB/EILM interfaces.



Function Description 
~~~~~~~~~~~~~~~~~~~~~~~~~

This section describes the SPI controller functions in four sub-sections
for master mode, slave mode, dual I/O mode, and quad I/O mode. The
master mode and slave mode describe the transfer initiation mechanism
and the SPI frame formats. The dual mode and quad mode describe the
other two transfer formats in compare to the regular mode.

Master Mode 
^^^^^^^^^^^^^^^^^^

The ATCSPI200 controller can act as a SPI master initiating SPI
transfers on the SPI bus. The SPI transfer format and interface timing
are programmable via the AHB/APB programing port. The SPI transfers are
initiated through the memory mapped read access on the AHB/EILM bus or
through direct register programming.

For SPI transfers initiated through the memory mapped AHB/EILM read
transactions, the read transactions are translated to the SPI interface
based on the read command format setup in the SPI Memory Access Control
Register. The default reset value of the register is hardware
configurable to support booting from SPI ROMs. The size of addressable
memory mapped space depends on the interface: up-to 16MB on the AHB bus
and up-to 1MB on the EILM bus.

For SPI transfers initiated by register programming, Figure 2 shows an
example of SPI transfer format which includes command, address, and data
phases for TX/RX data transfer. The controller provides dedicated
registers to specify the contents of command, address, and data fields.
The data register is shared by both TX and RX data transfers. The data
transfers can be initiated through Programmed IO (PIO) or Direct Memory
Access (DMA).

The ATCSPI200 controller provides TX/RX FIFO threshold interrupts to
ease flow control under the PIO programming. The controller also has a
programmable bit to issue an interrupt once the transfer completes.

In addition to the supported transfer format, the SPI controller allows
direct control of the signals on the SPI interface. This capability
enables communication with SPI devices which require special transfer
formats. See the SPI Direct IO Control Register (0x14) for more
information.

.. figure:: figure/SPI_Transfer_Format.png
   :scale: 25%

   SPI Transfer Format

Slave Mode 
^^^^^^^^^^^^^^^^^

The ATCSPI200 controller can also act as SPI slaves and accepts common
commands as shown in Table 1. In addition, the controller supports
user-defined commands where the slave data field format is defined by
the transfer control register.

The ATCSPI200 slave interprets the packet on the SPI I/O interface as
three fields: slave command, slave dummy and slave data. The slave
command field and slave dummy field are always 8-bit in length. The
slave data field format is defined by the received command and the
Transfer Control Register.

Table 1. Supported Commands under the Slave Mode

+--------------------------+-------------+--------------------------+
|    **Slave Command       | **OP Code** | **Slave Data**           |
|    Name**                |             |                          |
+==========================+=============+==========================+
|    Read Status Single IO | 0x05        | 32-bit Status            |
+--------------------------+-------------+--------------------------+
|    Read Status Dual IO   | 0x15        | 32-bit Status            |
+--------------------------+-------------+--------------------------+
|    Read Status Quad IO   | 0x25        | 32-bit Status            |
+--------------------------+-------------+--------------------------+
|    Read Data Single IO   | 0x0B        | Reply data from the Data |
|                          |             | Register in the FIFO     |
|                          |             | manner                   |
+--------------------------+-------------+--------------------------+
|    Read Data Dual IO     | 0x0C        | Reply data from the Data |
|                          |             | Register in the FIFO     |
|                          |             | manner                   |
+--------------------------+-------------+--------------------------+
|    Read Data Quad IO     | 0x0E        | Reply data from the Data |
|                          |             | Register in the FIFO     |
|                          |             | manner                   |
+--------------------------+-------------+--------------------------+
|    Write Data Single IO  | 0x51        | Data saved to the Data   |
|                          |             | Register in the FIFO     |
|                          |             | manner                   |
+--------------------------+-------------+--------------------------+
|    Write Data Dual IO    | 0x52        | Data saved to the Data   |
|                          |             | Register in the FIFO     |
|                          |             | manner                   |
+--------------------------+-------------+--------------------------+
|    Write Data Quad IO    | 0x54        | Data saved to the Data   |
|                          |             | Register in the FIFO     |
|                          |             | manner                   |
+--------------------------+-------------+--------------------------+
|    User-defined          | Any 8-bit   | Depending on the         |
|                          | numbers     | Transfer Controller      |
|                          | other than  | Register                 |
|                          | the listed  |                          |
|                          | OP Codes    |                          |
+--------------------------+-------------+--------------------------+
     

For the status-reading commands, the slave returns the value of the Slave 
Status Register. The protocol format is illustrated in Figure 3.

.. figure:: figure/fig3.png
   :scale: 25%

   Figure 3. Timing Diagram of Status-Reading Commands (MSB First,
   DataMerge=0)

For the data-reading commands, the protocol formats are illustrated in
Figure 4, Figure 5, and Figure 6.

.. figure:: figure/fig4.png
   :scale: 25%

   Timing Diagram of Data-Reading Commands (MSB First, Merge
   Mode)

.. figure:: figure/fig5.png
   :scale: 25%

   Timing Diagram of Data-Writing Commands (MSB First, Merge
   Mode)

.. figure:: figure/fig6.png
   :scale: 25%

   Timing Diagram of Data-Reading Commands (MSB First, Data
   Length = 16 Bits)

For the user-defined command, the slave data field format is defined by
the transfer control register (0x20). For example, if the transfer mode
is {Dummy, Write}, only the write field will be logged into the data
register and the dummy field is dropped.

.. figure:: figure/fig7.png
   :scale: 25%

   Figure 7. Timing Diagram of Slave User-Defined Command (MSB First, Merge
   Mode, TransMode = {Dummy, Write}, DualQuad = Quad, DummyCnt = 1, WrTranCnt = 3, 
   Data length = 8 Bits)

Dual I/O Mode 
^^^^^^^^^^^^^^^^^^^^

The dual I/O mode doubles the SPI bandwidth by treating the
master-input/slave-output (MISO) and master-output/slave-input (MOSI)
signals as bidirectional wires. The SPI controller provides two transfer
formats at the dual I/O mode. In one format, both the 
address phase and the data phase make use of the two wires (MISO and
MOSI). In the other format, only the data phase makes use of the
two wires. See AddrFmt and DualQuad bits in the SPI Transfer Format Register 
(section 3.2.4) for more information. Figure 8 shows an example of dual I/O 
transfer.

.. figure:: figure/fig8.png
   :scale: 25%

   SPI Dual I/O Transfer (3-byte address)

Quad I/O Mode 
^^^^^^^^^^^^^^^^^^^^

The quad I/O mode quadruples the SPI bandwidth by treating the
master-input/slave-output (MISO), master-output/slave-input (MOSI),
write protect (WP), and HOLD signals as bidirectional wires. The SPI
controller provides two transfer formats at the quad I/O
mode. In one format, both the address phase and data phase make use of
the four wires (MISO, MOSI, WP and HOLD). In the other format, only the data
phase makes use of the four wires. See AddrFmt and DualQuad bits in the
SPI Transfer Format Register (section 3.2.4) for more information.
Figure 9 shows an example of quad I/O transfer.

.. figure:: figure/fig9.png
   :scale: 25%

   SPI Quad I/O Mode Transfer (3-byte address)


Basic Block Diagram 
~~~~~~~~~~~~~~~~~~~~~

Figure 1 shows the block diagram of the ATCSPI200 controller.

.. figure:: figure/SPI_Block_Diagram.png
   :scale: 25%

   ATCSPI200 Block Diagram


SPI Register 
~~~~~~~~~~~~~~~~~~~~~~~~~

ID and Revision Register (0x00) 
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

This register holds the ID number and the revision number. The reset
values of the two revision fields are revision dependent.

Table 4. ID and Revision Register

=========== ======= ======== ======================= ==================
   **Name** **Bit** **Type** **Description**         **Reset**
=========== ======= ======== ======================= ==================
   ID       31:12   RO       ID number for ATCSPI200 0x02002
   RevMajor 11:4    RO       Major revision number   Revision dependent
   RevMinor 3:0     RO       Minor revision number   Revision dependent
=========== ======= ======== ======================= ==================

Transfer Format Register (0x10) 
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

This register defines the SPI transfer format.

+--------------+---------+----------+-------------------------+--------------------------+
|    **Name**  | **Bit** | **Type** | **Description**         | **Reset**                |
+==============+=========+==========+=========================+==========================+
|    Reserved  | 31:18   | \-       |    \-                   | \-                       |
+--------------+---------+----------+-------------------------+--------------------------+
|    AddrLen   | 17:16   | RW       | Address length          | 0x2                      |
|              |         |          | in bytes                |                          |
|              |         |          |                         |                          |
|              |         |          | 0x0: 1 bytes            |                          |
|              |         |          |                         |                          |
|              |         |          | 0x1: 2 bytes            |                          |
|              |         |          |                         |                          |
|              |         |          | 0x2: 3 bytes            |                          |
|              |         |          |                         |                          |
|              |         |          | 0x3: 4 bytes            |                          |
+--------------+---------+----------+-------------------------+--------------------------+
|    Reserved  | 15:13   | \-       |    \-                   | \-                       |
+--------------+---------+----------+-------------------------+--------------------------+
|    DataLen   | 12:8    | RW       | The length of           | 0x07                     |
|              |         |          | each data unit          |                          |
|              |         |          | in bits.                |                          |
|              |         |          |                         |                          |
|              |         |          | The actual bit          |                          |
|              |         |          | number of a             |                          |
|              |         |          | data unit is            |                          |
|              |         |          | (DataLen + 1)           |                          |
+--------------+---------+----------+-------------------------+--------------------------+
|    DataMerge | 7       | RW       | Enable Data             | 0x1                      |
|              |         |          | Merge mode,             |                          |
|              |         |          | which does              |                          |
|              |         |          | automatic data          |                          |
|              |         |          | split on write          |                          |
|              |         |          | and data                |                          |
|              |         |          | coaleasing on           |                          |
|              |         |          | read.                   |                          |
|              |         |          |                         |                          |
|              |         |          | This bit only           |                          |
|              |         |          | takes effect            |                          |
|              |         |          | when DataLen =          |                          |
|              |         |          | 0x7. Under Data         |                          |
|              |         |          | Merge mode,             |                          |
|              |         |          | each write to           |                          |
|              |         |          | the Data                |                          |
|              |         |          | Register will           |                          |
|              |         |          | transmit all            |                          |
|              |         |          | fourbytes of            |                          |
|              |         |          | the write data;         |                          |
|              |         |          | each read from          |                          |
|              |         |          | the Data                |                          |
|              |         |          | Register will           |                          |
|              |         |          | retrieve four           |                          |
|              |         |          | bytes of                |                          |
|              |         |          | received data           |                          |
|              |         |          | as a single             |                          |
|              |         |          | word data.              |                          |
|              |         |          |                         |                          |
|              |         |          | When Data               |                          |
|              |         |          | Merge mode              |                          |
|              |         |          | is disabled,            |                          |
|              |         |          | only the                |                          |
|              |         |          | least                   |                          |
|              |         |          | (DataLen+1)             |                          |
|              |         |          | significient            |                          |
|              |         |          | bits of the             |                          |
|              |         |          | Data                    |                          |
|              |         |          | Register are            |                          |
|              |         |          | valid for               |                          |
|              |         |          | read/write              |                          |
|              |         |          | operations;             |                          |
|              |         |          | no automatic            |                          |
|              |         |          | data                    |                          |
|              |         |          | split/coaleasing        |                          |
|              |         |          | will be                 |                          |
|              |         |          | performed.              |                          |
+--------------+---------+----------+-------------------------+--------------------------+
|    Reserved  | 6:5     | \-       |    \-                   | \-                       |
+--------------+---------+----------+-------------------------+--------------------------+
|    MOSIBiDir | 4       | RW       | Bi-directional          | 0x0                      |
|              |         |          | MOSI in regular         |                          |
|              |         |          | (single) mode.          |                          |
|              |         |          |                         |                          |
|              |         |          | 0x0: MOSI is            |                          |
|              |         |          | uni-directional         |                          |
|              |         |          | signal in               |                          |
|              |         |          | regular mode.           |                          |
|              |         |          |                         |                          |
|              |         |          | 0x1: MOSI is            |                          |
|              |         |          | bi-directional          |                          |
|              |         |          | signal in               |                          |
|              |         |          | regular mode.           |                          |
|              |         |          |                         |                          |
|              |         |          | This                    |                          |
|              |         |          | bi-directional          |                          |
|              |         |          | signal replaces         |                          |
|              |         |          | the two                 |                          |
|              |         |          | uni-directional         |                          |
|              |         |          | data signals,           |                          |
|              |         |          | MOSI and MISO.          |                          |
+--------------+---------+----------+-------------------------+--------------------------+
|    LSB       | 3       | RW       | Transfer data           | 0x0                      |
|              |         |          | with least              |                          |
|              |         |          | significant bit         |                          |
|              |         |          | first.                  |                          |
|              |         |          |                         |                          |
|              |         |          | 0x0: Most               |                          |
|              |         |          | significant bit         |                          |
|              |         |          | first                   |                          |
|              |         |          |                         |                          |
|              |         |          | 0x1: Least              |                          |
|              |         |          | significant bit         |                          |
|              |         |          | first                   |                          |
+--------------+---------+----------+-------------------------+--------------------------+
|    LSB       | 3       | RW       | Transfer data           | 0x0                      |
|              |         |          | with least              |                          |
|              |         |          | significant bit         |                          |
|              |         |          | first.                  |                          |
|              |         |          |                         |                          |
|              |         |          | 0x0: Most               |                          |
|              |         |          | significant bit         |                          |
|              |         |          | first                   |                          |
|              |         |          |                         |                          |
|              |         |          | 0x1: Least              |                          |
|              |         |          | significant bit         |                          |
|              |         |          | first                   |                          |
+--------------+---------+----------+-------------------------+--------------------------+
|    SlvMode   | 2       | RW       | SPI Master/Slave        | Depends on the input pin |
|              |         |          | mode selection          |                          |
|              |         |          |                         | spi_default_as_slave     |
|              |         |          | 0x0: Master mode        |                          |
|              |         |          |                         |                          |
|              |         |          | 0x1: Slave mode         |                          |
|              |         |          |                         |                          |
|              |         |          | (Exist only when        |                          |
|              |         |          | configuration           |                          |
|              |         |          | ATCSPI200_SLAVE_SUPPORT |                          |
|              |         |          | is defined)             |                          |
+--------------+---------+----------+-------------------------+--------------------------+
|    CPOL      | 1       | RW       | SPI Clock Polarity      | Depends on the input pin |
|              |         |          |                         |                          |
|              |         |          | 0x0: SCLK is LOW in the | spi_default_mode3        |
|              |         |          | idle states             |                          |
|              |         |          |                         |                          |
|              |         |          | 0x1: SCLK is HIGH in    |                          |
|              |         |          | the idle states         |                          |
+--------------+---------+----------+-------------------------+--------------------------+
|    CPHA      | 0       | RW       | SPI Clock Phase         | Depends on the input pin |
|              |         |          |                         |                          |
|              |         |          | 0x0: Sampling data at   | spi_default_mod3         |
|              |         |          | odd SCLK edges          |                          |
|              |         |          |                         |                          |
|              |         |          | 0x1: Sampling data at   |                          |
|              |         |          | even SCLK edges         |                          |
+--------------+---------+----------+-------------------------+--------------------------+

Direct IO Control Register (0x14) 
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

This register enables the direct control of the SPI interface signals.
The register is valid only when the configuration
ATCSPI200_DIRECT_IO_SUPPORT is defined.

+---------------+---------+----------+-----------------+---------------+
|    **Name**   | **Bit** | **Type** | **Description** | **Reset**     |
+===============+=========+==========+=================+===============+
|    Reserved   | 31:25   | \-       | \-              | \-            |
+---------------+---------+----------+-----------------+---------------+
|    DirectIOEn | 24      | RW       | Enable Direct   | 0x0           |
|               |         |          | IO              |               |
|               |         |          |                 |               |
|               |         |          | 0x0: Disable    |               |
|               |         |          |                 |               |
|               |         |          | 0x1: Enable     |               |
+---------------+---------+----------+-----------------+---------------+
|    Reserved   | 23:22   | \-       | \-              |\ -            |
+---------------+---------+----------+-----------------+---------------+
|    HOLD_OE    | 21      | RW       | Output enable   | 0x0           |
|               |         |          | for the SPI     |               |
|               |         |          | Flash hold      |               |
|               |         |          | signal          |               |
+---------------+---------+----------+-----------------+---------------+
|    WP_OE      | 20      | RW       | Output enable   | 0x0           |
|               |         |          | for the SPI     |               |
|               |         |          | Flash write     |               |
|               |         |          | protect         |               |
|               |         |          | signal          |               |
+---------------+---------+----------+-----------------+---------------+
|    MISO_OE    | 19      | RW       | Output enable   | 0x0           |
|               |         |          | fo the SPI      |               |
|               |         |          | MISO signal     |               |
+---------------+---------+----------+-----------------+---------------+
|    MOSI_OE    | 18      | RW       | Output enable   | 0x0           |
|               |         |          | for the SPI     |               |
|               |         |          | MOSI signal     |               |
+---------------+---------+----------+-----------------+---------------+
|    SCLK_OE    | 17      | RW       | Output enable   | 0x0           |
|               |         |          | for the SPI     |               |
|               |         |          | SCLK signal     |               |
+---------------+---------+----------+-----------------+---------------+
|    CS_OE      | 16      | RW       | Output enable   | 0x0           |
|               |         |          | for SPI CS      |               |
|               |         |          | (chip select)   |               |
|               |         |          | signal          |               |
+---------------+---------+----------+-----------------+---------------+
|    Reserved   | 15:14   | \-       | \-              | \-            |
+---------------+---------+----------+-----------------+---------------+
|    HOLD_O     | 13      | RW       | Output value    | 0x1           |
|               |         |          | for the SPI     |               |
|               |         |          | Flash hold      |               |
|               |         |          | signal          |               |
+---------------+---------+----------+-----------------+---------------+
|    WP_O       | 12      | RW       | Output value    | 0x1           |
|               |         |          | for the SPI     |               |
|               |         |          | Flash write     |               |
|               |         |          | protect         |               |
|               |         |          | signal          |               |
+---------------+---------+----------+-----------------+---------------+
|    MISO_O     | 11      | RW       | Output value    | 0x0           |
|               |         |          | for the SPI     |               |
|               |         |          | MISO signal     |               |
+---------------+---------+----------+-----------------+---------------+
|    MOSI_O     | 10      | RW       | Output value    | 0x0           |
|               |         |          | for the SPI     |               |
|               |         |          | MOSI signal     |               |
+---------------+---------+----------+-----------------+---------------+
|    SCLK_O     | 9       | RW       | Output value    | 0x0           |
|               |         |          | for the SPI     |               |
|               |         |          | SCLK signal     |               |
+---------------+---------+----------+-----------------+---------------+
|    CS_O       | 8       | RW       | Output value    | 0x1           |
|               |         |          | for the SPI     |               |
|               |         |          | CS (chip        |               |
|               |         |          | select)         |               |
|               |         |          | signal          |               |
+---------------+---------+----------+-----------------+---------------+
|    Reserved   | 7:6     | \-       | \-              | \-            |
+---------------+---------+----------+-----------------+---------------+
|    HOLD_I     | 5       | RO       | Status of the   | Depends on    |
|               |         |          | SPI Flash       | the status of |
|               |         |          | hold signal     | the           |
|               |         |          |                 | spi_hold_n_in |
|               |         |          |                 | pin           |
+---------------+---------+----------+-----------------+---------------+
|    WP_I       | 4       | RO       | Status of the   | Depends on    |
|               |         |          | SPI Flash       | the status of |
|               |         |          | write protect   | the           |
|               |         |          | signal          | spi_wp_n_in   |
|               |         |          |                 | pin           |
+---------------+---------+----------+-----------------+---------------+
|    MISO_I     | 3       | RO       | Status of the   | Depends on    |
|               |         |          | SPI MISO signal | the status of |
|               |         |          |                 | the           |
|               |         |          |                 | spi_miso_in   |
|               |         |          |                 | pin           |
+---------------+---------+----------+-----------------+---------------+
|    MOSI_I     | 2       | RO       | Status of the   | Depends on    |
|               |         |          | SPI MOSI signal | the status of |
|               |         |          |                 | the           |
|               |         |          |                 | spi_mosi_in   |
|               |         |          |                 | pin           |
+---------------+---------+----------+-----------------+---------------+
|    SCLK_I     | 1       | RO       | Status of the   | Depends on    |
|               |         |          | SPI SCLK signal | the status of |
|               |         |          |                 | the           |
|               |         |          |                 | spi_clk_in    |
|               |         |          |                 | pin           |
+---------------+---------+----------+-----------------+---------------+
|    CS_I       | 0       | RO       | Status of the   | Depends on    |
|               |         |          | SPI CS          | the status of |  
|               |         |          | (chip select)   | the           |
|               |         |          | signal          | spi_cs_n_in   |
|               |         |          |                 | pin           |
+---------------+---------+----------+-----------------+---------------+

Transfer Control Register (0x20) 
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

This register controls aspects of SPI transfers. Please see section 0
for starting a SPI transfer.

+--------------+---------+----------+------------------------+------------+
|    **Name**  | **Bit** | **Type** | **Description**        | **Reset**  |
+==============+=========+==========+========================+============+
|    CmdEn     | 30      | RW       | The SPI command phase  | 0x0        |
|              |         |          | enable                 |            |
|              |         |          |                        |            |
|              |         |          | 0x0: Disable the       |            |
|              |         |          | command phase          |            |
|              |         |          |                        |            |
|              |         |          | 0x1: Enable the        |            |
|              |         |          | command phase          |            |
|              |         |          |                        |            |
|              |         |          | (Master mode only)     |            |
+--------------+---------+----------+------------------------+------------+
|    AddrEn    | 29      | RW       | The SPI address phase  | 0x0        |
|              |         |          | enable                 |            |
|              |         |          |                        |            |
|              |         |          | 0x0: Disable the       |            |
|              |         |          | address phase          |            |
|              |         |          |                        |            |
|              |         |          | 0x1: Enable the        |            |
|              |         |          | address phase          |            |
|              |         |          |                        |            |
|              |         |          | (Master mode only)     |            |
+--------------+---------+----------+------------------------+------------+
|    AddrFmt   | 28      | RW       | The SPI address phase  | 0x0        |
|              |         |          | format                 |            |
|              |         |          |                        |            |
|              |         |          | 0x0: Address phase is  |            |
|              |         |          | the regular (single)   |            |
|              |         |          | mode                   |            |
|              |         |          |                        |            |
|              |         |          | 0x1: The format        |            |
|              |         |          | of the address phase   |            |
|              |         |          | is the same as the     |            |
|              |         |          | data phase (DualQuad). |            |
|              |         |          |                        |            |
|              |         |          | (Master mode only)     |            |
+--------------+---------+----------+------------------------+------------+
|    TransMode | 27:24   | RW       | The transfer mode      | 0x0        |
|              |         |          |                        |            |
|              |         |          | The transfer sequence  |            |
|              |         |          | could be               |            |
|              |         |          |                        |            |
|              |         |          | 0x0: Write and read at |            |
|              |         |          | the same time          |            |
|              |         |          |                        |            |
|              |         |          | 0x1: Write only        |            |
|              |         |          |                        |            |
|              |         |          | 0x2: Read only         |            |
|              |         |          |                        |            |
|              |         |          | 0x3: Write, Read       |            |
|              |         |          |                        |            |
|              |         |          | 0x4: Read, Write       |            |
|              |         |          |                        |            |
|              |         |          | 0x5: Write, Dummy,     |            |
|              |         |          | Read                   |            |
|              |         |          |                        |            |
|              |         |          | 0x6: Read, Dummy,      |            |
|              |         |          | Write                  |            |
|              |         |          |                        |            |
|              |         |          | 0x7: None Data (must   |            |
|              |         |          | enable CmdEn or AddrEn |            |
|              |         |          | in Master mode)        |            |
|              |         |          |                        |            |
|              |         |          | 0x8: Dummy, Write      |            |
|              |         |          |                        |            |
|              |         |          | 0x9: Dummy, Read       |            |
|              |         |          |                        |            |
|              |         |          | 0xa~0xf: Reserved      |            |
+--------------+---------+----------+------------------------+------------+
|    DualQuad  | 23:22   | RW       | The SPI data phase     | 0x0        |
|              |         |          | format                 |            |
|              |         |          |                        |            |
|              |         |          | 0x0: Regular (Single)  |            |
|              |         |          | mode                   |            |
|              |         |          |                        |            |
|              |         |          | 0x1: Dual I/O mode     |            |
|              |         |          |                        |            |
|              |         |          | 0x2: Quad I/O mode     |            |
|              |         |          |                        |            |
|              |         |          | 0x3: Reserved          |            |
+--------------+---------+----------+------------------------+------------+
|    TokenEn   | 21      | RW       | Append an one-byte     | 0x0        |
|              |         |          | special token          |            |
|              |         |          | following the          |            |
|              |         |          | address phase          |            |
|              |         |          | for SPI read           |            |
|              |         |          | transfers.             |            |
|              |         |          |                        |            |
|              |         |          | The value of the       |            |
|              |         |          | special token          |            |
|              |         |          | should be selected     |            |
|              |         |          | in the TokenValue.     |            |
|              |         |          |                        |            |
|              |         |          | 0x0: Disable the       |            |
|              |         |          | one-byte special token |            |
|              |         |          |                        |            |
|              |         |          | 0x1: Enable the        |            |
|              |         |          | one-byte special token |            |
|              |         |          |                        |            |
|              |         |          | (Master mode only)     |            |
+--------------+---------+----------+------------------------+------------+
|    WrTranCnt | 20:12   | RW       | Transfer count for     | 0x0        |
|              |         |          | write data             |            |
|              |         |          |                        |            |
|              |         |          | WrTranCnt              |            |
|              |         |          | indicates the          |            |
|              |         |          | number of units of     |            |
|              |         |          | data to be             |            |
|              |         |          | transmitted to the     |            |
|              |         |          | SPI bus from the       |            |
|              |         |          | Data Register. The     |            |
|              |         |          | actual transfer        |            |
|              |         |          | count is               |            |
|              |         |          | (WrTranCnt+1).         |            |
|              |         |          |                        |            |
|              |         |          | WrTranCnt only takes   |            |
|              |         |          | effect when TransMode  |            |
|              |         |          | is 0, 1, 3, 4, 5, 6    |            |
|              |         |          | or 8.                  |            |
|              |         |          |                        |            |
|              |         |          | The size (bit-width)   |            |
|              |         |          | of a data unit is      |            |
|              |         |          | defined by the         |            |
|              |         |          | DataLen field of the   |            |
|              |         |          | Transfer Format        |            |
|              |         |          | Register. For          |            |
|              |         |          | TransMode 0,           |            |
|              |         |          | WrTranCnt must be      |            |
|              |         |          | equal to RdTranCnt.    |            |
+--------------+---------+----------+------------------------+------------+
|   TokenValue | 11      | RW       | The value of the       | 0x0        |
|              |         |          | one-byte special       |            |
|              |         |          | token following        |            |
|              |         |          | the address phase      |            |
|              |         |          | for SPI read           |            |
|              |         |          | transfers.             |            |
|              |         |          |                        |            |
|              |         |          | 0x0: token value =     |            |
|              |         |          | 0x00                   |            |
|              |         |          |                        |            |
|              |         |          | 0x1: token value =     |            |
|              |         |          | 0x69                   |            |
|              |         |          |                        |            |
|              |         |          | (Master mode only)     |            |
+--------------+---------+----------+------------------------+------------+
|    DummyCnt  | 10:9    | RW       | Dummy data count. The  | 0x0        |
|              |         |          | actual dummy count is  |            |
|              |         |          | (DummyCnt +1).         |            |
|              |         |          |                        |            |
|              |         |          | The number of dummy    |            |
|              |         |          | cycles on the SPI      |            |
|              |         |          | interface will be      |            |
|              |         |          | (DummyCnt+1)\*         |            |
|              |         |          | ((DataLen+1)/SPI IO    |            |
|              |         |          | width)                 |            |
|              |         |          |                        |            |
|              |         |          | The Data pins are put  |            |
|              |         |          | into the high          |            |
|              |         |          | impedance during       |            |
|              |         |          | the dummy data phase.  |            |
|              |         |          |                        |            |
|              |         |          | DummyCnt is only used  |            |
|              |         |          | for TransMode 5, 6, 8  |            |
|              |         |          | and 9, which has dummy |            |
|              |         |          | data phases.           |            |
|              |         |          |                        |            |
|              |         |          | Following table shows  |            |
|              |         |          | dummy cycle settings   |            |
|              |         |          | under some common      |            |
|              |         |          | transfer formats:      |            |
|              |         |          |                        |            |
|              |         |          | .. figure:: intab.png  |            |
|              |         |          |    :scale: 45%         |            |
+--------------+---------+----------+------------------------+------------+
|    RdTranCnt | 8:0     | RW       | Transfer count for     | 0x0        |
|              |         |          | read data              |            |
|              |         |          |                        |            |
|              |         |          | RdTranCnt              |            |
|              |         |          | indicates the          |            |
|              |         |          | number of units of     |            |
|              |         |          | data to be             |            |
|              |         |          | received from the      |            |
|              |         |          | SPI bus and stored to  |            |
|              |         |          | the Data Register. The |            |
|              |         |          | actual received        |            |
|              |         |          | count is               |            |
|              |         |          | (RdTranCnt+1).         |            |
|              |         |          |                        |            |
|              |         |          | RdTranCnt only takes   |            |
|              |         |          | effect when TransMode  |            |
|              |         |          | is 0, 2, 3, 4, 5, 6    |            |
|              |         |          | or 9.                  |            |
|              |         |          |                        |            |
|              |         |          | The size (bit-width)   |            |
|              |         |          | of a data unit is      |            |
|              |         |          | defined by the         |            |
|              |         |          | DataLen field of the   |            |
|              |         |          | Transfer Format        |            |
|              |         |          | Register. For          |            |
|              |         |          | TransMode 0,           |            |
|              |         |          | WrTranCnt must be      |            |
|              |         |          | equal to RdTranCnt.    |            |
+--------------+---------+----------+------------------------+------------+  


SPI Command Register (0x24) 
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

Write operations on this register trigger SPI transfers. This register
must be written with a dummy value to start a SPI transfer even when the
command phase is not enabled. When the ATCSPI200 controller is
programmed to the slave mode, the command field of the last received SPI
transaction is stored in this SPI Command Register.

Table 8. SPI Command Register

+--------------+---------+----------+------------------------+------------+
|    **Name**  | **Bit** | **Type** | **Description**        | **Reset**  |
+==============+=========+==========+========================+============+
|    Reserved  | 31:8    | \-       | \-                     | \-         |
+--------------+---------+----------+------------------------+------------+
|    CMD       | 7:0     | RW       | SPI Command            | 0x0        |
+--------------+---------+----------+------------------------+------------+

SPI Address Register (0x28) 
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

Table 9. SPI Address Register  

+--------------+---------+----------+------------------------+------------+
|    **Name**  | **Bit** | **Type** | **Description**        | **Reset**  |
+==============+=========+==========+========================+============+
|    ADDR      | 31:0    | RW       | SPI Address            | 0x0        |
|              |         |          | (Master mode only)     |            |
+--------------+---------+----------+------------------------+------------+


SPI Data Register (0x2C) 
^^^^^^^^^^^^^^^^^^^^^^^^^^^

When the controller is in the data merge mode, the byte endian of the
SPI Data Register is little endian.

Table 10. SPI Data Register

+-----------+---------+----------+-----------------------------------------------------------------------+------------+
| **Name**  | **Bit** | **Type** | **Description**                                                       | **Reset**  |
+===========+=========+==========+=======================================================================+============+
| DATA      | 31:0    | RW       | Data to transmit or the received data                                 |  0x0       |
|           |         |          |                                                                       |            |
|           |         |          | For writes, data is enqueued to the TX FIFO. The                      |            |
|           |         |          | least significant byte is always transmitted first.                   |            |
|           |         |          |                                                                       |            |
|           |         |          | For reads, data is read and dequeued from the RX FIFO. The least      |            |
|           |         |          | significant byte is the first received byte.                          |            |
|           |         |          |                                                                       |            |
|           |         |          | The FIFOs decouple the speed of the SPI transfers and the software’s  |            |
|           |         |          | generation/consumption of data. When the TX FIFO is empty, SPI        |            |
|           |         |          | transfers will hold until more data is written to the TX FIFO; when   |            |
|           |         |          | the RX FIFO is full, SPI transfers will hold until there is more room |            |
|           |         |          | in the RX FIFO.                                                       |            |
|           |         |          |                                                                       |            |
|           |         |          | If more data is written to the TX FIFO than the write transfer count  |            |
|           |         |          | (WrTranCnt), the remaining data will stay in the TX FIFO for the next |            |
|           |         |          | transfer or until the TX FIFO is reset.                               |            |
|           |         |          |                                                                       |            |
|           |         |          |                                                                       |            |
+-----------+---------+----------+-----------------------------------------------------------------------+------------+

SPI Control Register (0x30) 
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

Table 11 SPI Control Register

+--------------+---------+----------+------------------------+------------+
|    **Name**  | **Bit** | **Type** | **Description**        | **Reset**  |
+==============+=========+==========+========================+============+
|    Reserved  | 31:21   | \-       | \-                     | \-         |
+--------------+---------+----------+------------------------+------------+
|    TXTHRES   | 20:16   | RW       | Transmit (TX) FIFO     | 0x0        |
|              |         |          | Threshold              |            |
|              |         |          |                        |            |
|              |         |          | The TXFIFOInt          |            |
|              |         |          | interrupt or DMA       |            |
|              |         |          | request would be       |            |
|              |         |          | issued to replenish    |            |
|              |         |          | the TX FIFO when the   |            |
|              |         |          | TX data count is less  |            |
|              |         |          | than or equal to the   |            |
|              |         |          | TX FIFO threshold.     |            |
+--------------+---------+----------+------------------------+------------+
|    Reserved  | 15:13   | \-       | \-                     | \-         |
+--------------+---------+----------+------------------------+------------+
|    RXTHRES   | 12:8    | RW       | Receive (RX) FIFO      | 0x0        |
|              |         |          | Threshold              |            |
|              |         |          |                        |            |
|              |         |          | The RXFIFOInt          |            |
|              |         |          | interrupt or DMA       |            |
|              |         |          | request would be       |            |
|              |         |          | issued for consuming   |            |
|              |         |          | the RX FIFO when the   |            |
|              |         |          | RX data count is more  |            |
|              |         |          | than or equal to the   |            |
|              |         |          | RX FIFO threshold.     |            |
+--------------+---------+----------+------------------------+------------+
|    Reserved  | 7:5     | \-       | \-                     | \-         |
+--------------+---------+----------+------------------------+------------+
|    TXDMAEN   | 4       | RW       | TX DMA enable          | 0x0        |
+--------------+---------+----------+------------------------+------------+
|    RXDMAEN   | 3       | RW       | RX DMA enable          | 0x0        |
+--------------+---------+----------+------------------------+------------+
|    TXFIFORST | 2       | RW       | Transmit FIFO reset    | 0x0        |
|              |         |          |                        |            |
|              |         |          | Write 1 to reset. It   |            |
|              |         |          | is cleared to 0 after  |            |
|              |         |          | the reset operation    |            |
|              |         |          | completes.             |            |
+--------------+---------+----------+------------------------+------------+
|    RXFIFORST | 1       | RW       | Receive FIFO reset     | 0x0        |
|              |         |          |                        |            |
|              |         |          | Write 1 to reset. It   |            |
|              |         |          | is cleared to 0 after  |            |
|              |         |          | the reset operation    |            |
|              |         |          | completes.             |            |
+--------------+---------+----------+------------------------+------------+
|    SPIRST    | 0       | RW       | SPI reset              | 0x0        |
|              |         |          |                        |            |
|              |         |          | Write 1 to reset. It   |            |
|              |         |          | is cleared to 0 after  |            |
|              |         |          | the reset operation    |            |
|              |         |          | completes.             |            |
+--------------+---------+----------+------------------------+------------+

SPI Status Register (0x34) 
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

Table 12 SPI Status Register

============ ======== ========== ============================================== =========
**Name**     **Bit**  **Type**   **Description**                                **Reset**
============ ======== ========== ============================================== =========
Reserved     31:24    \-         \-                                             \-
TXFULL       23       RO         Transmit FIFO Full flag                        0x0
TXEMPTY      22       RO         Transmit FIFO Empty flag                       0x1
Reserved     21       \-         \-                                             \-
TXNUM        20:16    RO         Number of valid entries in the Transmit FIFO   0x0
RXFULL       15       RO         Receive FIFO Full flag                         0x0
RXEMPTY      14       RO         Receive FIFO Empty flag                        0x1
Reserved     13       \-         \-                                             \-
RXNUM        12:8     RO         Number of valid entries in the Receive FIFO    0x0
Reserved     7:1      \-         \-                                             \-
SPIActive    0        RO         SPI direct register programming is in progress 0x0
============ ======== ========== ============================================== =========

SPI Interrupt Enable Register (0x38) 
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

Table 13. SPI Interrupt Enable Register

+------------------+---------+----------+------------------+------------+
|    **Name**      | **Bit** | **Type** | **Description**  | **Reset**  |
+==================+=========+==========+==================+============+
|    Reserved      | 31:6    | \-       | \-               | \-         |
+------------------+---------+----------+------------------+------------+
|    SlvCmdEn      | 5       | RW       | Enable the Slave | 0x0        |
|                  |         |          | Command          |            |
|                  |         |          | interrupt.       |            |
|                  |         |          |                  |            |
|                  |         |          | Control whether  |            |
|                  |         |          | interrupts are   |            |
|                  |         |          | triggered        |            |
|                  |         |          | whenever         |            |
|                  |         |          | slave commands   |            |
|                  |         |          | are received     |            |
|                  |         |          | in the Slave     |            |
|                  |         |          | mode.            |            |
|                  |         |          |                  |            |
|                  |         |          | (Slave mode      |            |
|                  |         |          | only)            |            |
+------------------+---------+----------+------------------+------------+
|    EndIntEn      | 4       | RW       | Enable the End   | 0x0        |
|                  |         |          | of SPI Transfer  |            |
|                  |         |          | interrupt.       |            |
|                  |         |          |                  |            |
|                  |         |          | Control whether  |            |
|                  |         |          | interrupts are   |            |
|                  |         |          | triggered when   |            |
|                  |         |          | SPI transfers    |            |
|                  |         |          | end.             |            |
|                  |         |          |                  |            |
|                  |         |          | (In slave mode,  |            |
|                  |         |          | end of read      |            |
|                  |         |          | status           |            |
|                  |         |          | transaction      |            |
|                  |         |          | doesn’t trigger  |            |
|                  |         |          | this interrupt)  |            |
+------------------+---------+----------+------------------+------------+
|    TXFIFOIntEn   | 3       | RW       | Enable the SPI   | 0x0        |
|                  |         |          | Transmit FIFO    |            |
|                  |         |          | Threshold        |            |
|                  |         |          | interrupt.       |            |
|                  |         |          | Control whether  |            |
|                  |         |          | interrupts are   |            |
|                  |         |          | triggered when   |            |
|                  |         |          | the valid        |            |
|                  |         |          | entries are less |            |
|                  |         |          | than or equal to |            |
|                  |         |          | the TX FIFO      |            |
|                  |         |          | threshold.       |            |
+------------------+---------+----------+------------------+------------+
|    RXFIFOIntEn   | 2       | RW       | Enable the SPI   | 0x0        |
|                  |         |          | Receive FIFO     |            |
|                  |         |          | Threshold        |            |
|                  |         |          | interrupt.       |            |
|                  |         |          | Control whether  |            |
|                  |         |          | interrupts are   |            |
|                  |         |          | triggered when   |            |
|                  |         |          | the valid        |            |
|                  |         |          | entries are      |            |
|                  |         |          | greater than or  |            |
|                  |         |          | equal to the RX  |            |
|                  |         |          | FIFO threshold.  |            |
+------------------+---------+----------+------------------+------------+
|    TXFIFOURIntEn | 1       | RW       | Enable the SPI   | 0x0        |
|                  |         |          | Transmit FIFO    |            |
|                  |         |          | Underrun         |            |
|                  |         |          | interrupt.       |            |
|                  |         |          |                  |            |
|                  |         |          | Control whether  |            |
|                  |         |          | interrupts are   |            |
|                  |         |          | triggered when   |            |
|                  |         |          | the Transmit     |            |
|                  |         |          | FIFO run out of  |            |
|                  |         |          | data.            |            |
|                  |         |          |                  |            |
|                  |         |          | (Slave mode      |            |
|                  |         |          | only)            |            |
+------------------+---------+----------+------------------+------------+
|    RXFIFOORIntEn | 0       | RW       | Enable the SPI   | 0x0        |
|                  |         |          | Receive FIFO     |            |
|                  |         |          | Overrun          |            |
|                  |         |          | interrupt.       |            |
|                  |         |          | Control whether  |            |
|                  |         |          | interrupts are   |            |
|                  |         |          | triggered when   |            |
|                  |         |          | the Receive FIFO |            |
|                  |         |          | overflows.       |            |
|                  |         |          |                  |            |
|                  |         |          | (Slave mode      |            |
|                  |         |          | only)            |            |
+------------------+---------+----------+------------------+------------+

SPI Interrupt Status Register (0x3C) 
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

Table 14. SPI Interrupt Status Register 

+----------------+---------+----------+--------------------------+-----------+
|    **Name**    | **Bit** | **Type** | **Description**          | **Reset** |
+================+=========+==========+==========================+===========+
|    Reserved    | 31:6    | \-       | \-                       | \-        |
+----------------+---------+----------+--------------------------+-----------+
|    SlvCmdInt   | 5       | W1C      | Slave Command Interrupt. | 0x0       |
|                |         |          |                          |           |
|                |         |          | This bit is set when     |           |
|                |         |          | Slave Command            |           |
|                |         |          | interrupts occur.        |           |
|                |         |          |                          |           |
|                |         |          | (Slave mode only)        |           |
+----------------+---------+----------+--------------------------+-----------+
|    EndInt      | 4       | W1C      | End of SPI Transfer      | 0x0       |
|                |         |          | interrupt.               |           |
|                |         |          |                          |           |
|                |         |          | This bit is set when End |           |
|                |         |          | of SPI Transfer          |           |
|                |         |          | interrupts occur.        |           |
+----------------+---------+----------+--------------------------+-----------+
|    TXFIFOInt   | 3       | W1C      | TX FIFO Threshold        | 0x0       |
|                |         |          | interrupt.               |           |
|                |         |          |                          |           |
|                |         |          | This bit is set when TX  |           |
|                |         |          | FIFO Threshold           |           |
|                |         |          | interrupts occur.        |           |
+----------------+---------+----------+--------------------------+-----------+
|    RXFIFOInt   | 2       | W1C      | RX FIFO Threshold        | 0x0       |
|                |         |          | interrupt.               |           |
|                |         |          |                          |           |
|                |         |          | This bit is set when RX  |           |
|                |         |          | FIFO Threshold           |           |
|                |         |          | interrupts occur.        |           |
+----------------+---------+----------+--------------------------+-----------+
|    TXFIFOURInt | 1       | W1C      | TX FIFO Underrun         | 0x0       |
|                |         |          | interrupt.               |           |
|                |         |          |                          |           |
|                |         |          | This bit is set when TX  |           |
|                |         |          | FIFO Underrun interrupts |           |
|                |         |          | occur.                   |           |
|                |         |          |                          |           |
|                |         |          | (Slave mode only)        |           |
+----------------+---------+----------+--------------------------+-----------+
|    RXFIFOORInt | 0       | W1C      | RX FIFO Overrun          | 0x0       |
|                |         |          | interrupt.               |           |
|                |         |          |                          |           |
|                |         |          | This bit is set when RX  |           |
|                |         |          | FIFO Overrun interrupts  |           |
|                |         |          | occur.                   |           |
|                |         |          |                          |           |
|                |         |          | (Slave mode only)        |           |
+----------------+---------+----------+--------------------------+-----------+

SPI Interface Timing Register (0x40)
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

This register controls the SPI interface timing for satisfying the SPI
Slave interface timing requirements. Only the master needs program this
register.

Table 15. SPI Interface Timing Register

+----------------+---------+----------+--------------------------------------------------------------+---------------+
|    **Name**    | **Bit** | **Type** | **Description**                                              | **Reset**     |
+================+=========+==========+==============================================================+===============+
|    Reserved    | 31:14   | \-       | \-                                                           | \-            |
+----------------+---------+----------+--------------------------------------------------------------+---------------+
|    CS2SCLK     | 13:12   | RW       | The minimum time between the edges of SPI CS                 | Configuration |
|                |         |          | and the edges of SCLK.                                       | dependent     |
|                |         |          |                                                              |               |
|                |         |          | The actual duration is                                       |               |
|                |         |          | :math:`\frac{SCLK period}{2} * (CS2SCLK + 1)`                |               |
|                |         |          |                                                              |               |
+----------------+---------+----------+--------------------------------------------------------------+---------------+
|    CSHT        | 11:8    | RW       | The minimum time that SPI CS should stay HIGH.               | Configuration |
|                |         |          |                                                              | dependent     |
|                |         |          | The actual duration is                                       |               |
|                |         |          | :math:`\frac{SCLK period}{2} * (CSHT + 1)`                   |               |
|                |         |          |                                                              |               |
+----------------+---------+----------+--------------------------------------------------------------+---------------+
|    SCLK_DIV    | 7:0     | RW       | The clock frequency ratio between the clock source and SPI   | Configuration |
|                |         |          | interface SCLK.                                              | dependent     |
|                |         |          |                                                              |               |
|                |         |          | SCLK period =                                                |               |
|                |         |          | :math:`((SCLK\_DIV+1)*2)*(\text{Period of the SPI clock s})` |               |
|                |         |          |                                                              |               |
|                |         |          | The SCLK_DIV value 0xff is a special value                   |               |
|                |         |          | which indicates that the SCLK frequency                      |               |
|                |         |          | should be the same as the SPI source clock                   |               |
|                |         |          | frequency.                                                   |               |
+----------------+---------+----------+--------------------------------------------------------------+---------------+
   

Memory Access Control Register (0x50) 
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

This register defines the SPI command format for issuing the memory
mapped AHB/EILM read access. The memory mapped AHB/EILM read accesses
should be stopped prior to programming this register or the SPI
Interface Timing Register (0x40). The AHB/EILM accesses
could be resumed when MemCtrlChg bit is cleared.

Table 16. SPI Memory Access Control Register

+-------------+-------------+-------------+-----------------+-------------+
|    **Name** | **Bit**     | **Type**    | **Description** | **Reset**   |
+=============+=============+=============+=================+=============+
|    Reserved | 31:9        | \-          | \-              | \-          |
+-------------+-------------+-------------+-----------------+-------------+
|  MemCtrlChg | 8           | RO          | This bit is     | 0           |
|             |             |             | set when        |             |
|             |             |             | this            |             |
|             |             |             | register        |             |
|             |             |             | (0x50) or       |             |
|             |             |             | the SPI         |             |
|             |             |             | Interface       |             |
|             |             |             | Timing          |             |
|             |             |             | Register        |             |
|             |             |             | (0x40) is       |             |
|             |             |             | written; it     |             |
|             |             |             | is              |             |
|             |             |             | automatically   |             |
|             |             |             | cleared         |             |
|             |             |             | when the        |             |
|             |             |             | new             |             |
|             |             |             | programming     |             |
|             |             |             | takes           |             |
|             |             |             | effect.         |             |
+-------------+-------------+-------------+-----------------+-------------+
|    Reserved | 7:4         | \-          | \-              | \-          |
+-------------+-------------+-------------+-----------------+-------------+
|    MemRdCmd | 3:0         | RW          | Selects the     | Co          |
|             |             |             | SPI command     | nfiguration |
|             |             |             | format when     | dependent   |
|             |             |             | serving the     |             |
|             |             |             | memory          |             |
|             |             |             | mapped          |             |
|             |             |             | reads on        |             |
|             |             |             | the             |             |
|             |             |             | AHB/EILM        |             |
|             |             |             | bus The         |             |
|             |             |             | command         |             |
|             |             |             | encoding        |             |
|             |             |             | table is        |             |
|             |             |             | listed in       |             |
|             |             |             | Table 17.       |             |
|             |             |             |                 |             |
|             |             |             | The latency     |             |
|             |             |             | of each         |             |
|             |             |             | command is      |             |
|             |             |             | listed in       |             |
|             |             |             | Table 18.       |             |
+-------------+-------------+-------------+-----------------+-------------+

SPI Slave Status Register (0x60) 
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

The Slave Status Register keeps slave statuses. An SPI master can get
these statuses by issuing status-reading commands.

+---------------+---------+----------+-----------------+-----------+
|    **Name**   | **Bit** | **Type** | **Description** | **Reset** |
+===============+=========+==========+=================+===========+
|    Reserved   | 31:19   | \-       | \-              | \-        |
+---------------+---------+----------+-----------------+-----------+
|    UnderRun   | 18      | W1C      | Data underrun   | 0         |
|               |         |          | occurs in the   |           |
|               |         |          | last            |           |
|               |         |          | transaction     |           |
+---------------+---------+----------+-----------------+-----------+
|    OverRun    | 17      | W1C      | Data overrun    | 0         |
|               |         |          | occurs in the   |           |
|               |         |          | last            |           |
|               |         |          | transaction     |           |
+---------------+---------+----------+-----------------+-----------+
|    Ready      | 16      | RW       | Set this bit to | 0         |
|               |         |          | indicate that   |           |
|               |         |          | the ATCSPI200   |           |
|               |         |          | is ready for    |           |
|               |         |          | data            |           |
|               |         |          | transaction.    |           |
|               |         |          |                 |           |
|               |         |          | When an SPI     |           |
|               |         |          | transaction     |           |
|               |         |          | other than      |           |
|               |         |          | slave           |           |
|               |         |          | status-reading  |           |
|               |         |          | command ends,   |           |
|               |         |          | this bit will   |           |
|               |         |          | be cleared to   |           |
|               |         |          | 0.              |           |
+---------------+---------+----------+-----------------+-----------+
|    USR_Status | 15:0    | RW       | User defined    | 0         |
|               |         |          | status flags    |           |
+---------------+---------+----------+-----------------+-----------+

SPI Slave Data Count Register (0x64) 
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

This register shows the data count of the read/write transactions in the
slave mode. You should access the data register based on the data count
information.

============ ======== ========== ============================ =========
**Name**     **Bit**  **Type**   **Description**              **Reset**
============ ======== ========== ============================ =========
Reserved     31:25    \-         \-                           \- 
WCnt         24:16    RO         Slave transmitted data count 0
Reserved     15:9     \-         \-                           \- 
RCnt         8:0      RO         Slave received data count    0
============ ======== ========== ============================ =========

Configuration Register (0x7C) 
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

Table 21. Configuration Register

+-------------+---------+----------+-----------------+---------------+
|    **Name** | **Bit** | **Type** | **Description** | **Reset**     |
+=============+=========+==========+=================+===============+
|    Reserved | 31:15   | \-       | \-              | \-            |
+-------------+---------+----------+-----------------+---------------+
|    Slave    | 14      | RO       | Support for     | Configuration |
|             |         |          | SPI Slave       | dependent     |
|             |         |          | mode            |               |
+-------------+---------+----------+-----------------+---------------+
|    EILMMem  | 13      | RO       | Support for     | Configuration |
|             |         |          | memory mapped   | dependent     |
|             |         |          | access          |               |
|             |         |          | (read-only)     |               |
|             |         |          | through EILM    |               |
|             |         |          | bus             |               |
+-------------+---------+----------+-----------------+---------------+
|    AHBMem   | 12      | RO       | Support for     | Configuration |
|             |         |          | memory mapped   | dependent     |
|             |         |          | access          |               |
|             |         |          | (read-only)     |               |
|             |         |          | through AHB     |               |
|             |         |          | bus             |               |
+-------------+---------+----------+-----------------+---------------+
|    DirectIO | 11      | RO       | Support for     | Configuration |
|             |         |          | Direct SPI IO   | dependent     |
+-------------+---------+----------+-----------------+---------------+
|    Reserved | 10      | \-       | \-              | \-            |
+-------------+---------+----------+-----------------+---------------+
|    QuadSPI  | 9       | RO       | Support for     | Configuration |
|             |         |          | Quad I/O SPI    | dependent     |
+-------------+---------+----------+-----------------+---------------+
|    DualSPI  | 8       | RO       | Support for     | Configuration |
|             |         |          | Dual I/O SPI    | dependent     |
+-------------+---------+----------+-----------------+---------------+
|    Reserved | 7:6     | \-       | \-              | \-            |
+-------------+---------+----------+-----------------+---------------+
| TxFIFOSize  | 5:4     | RO       | Depth of TX     | Configuration |
|             |         |          | FIFO            | dependent     |
|             |         |          |                 |               |
|             |         |          | 0x0: 2 words    |               |
|             |         |          |                 |               |
|             |         |          | 0x1: 4 words    |               |
|             |         |          |                 |               |
|             |         |          | 0x2: 8 words    |               |
|             |         |          |                 |               |
|             |         |          | 0x3: 16 words   |               |
+-------------+---------+----------+-----------------+---------------+
|    Reserved | 3:2     | \-       | \-              | \-            |
+-------------+---------+----------+-----------------+---------------+
| RxFIFOSize  | 1:0     | RO       | Depth of RX     | Configuration |
|             |         |          | FIFO            | dependent     |
|             |         |          |                 |               |
|             |         |          | 0x0: 2 words    |               |
|             |         |          |                 |               |
|             |         |          | 0x1: 4 words    |               |
|             |         |          |                 |               |
|             |         |          | 0x2: 8 words    |               |
|             |         |          |                 |               |
|             |         |          | 0x3: 16 words   |               |
+-------------+---------+----------+-----------------+---------------+                                      
                          
                                      
                          
                                      
                          
                                      
                         



